import { 
  Product, InsertProduct, 
  Category, InsertCategory,
  Order, InsertOrder 
} from "@shared/schema";

// Define interface with CRUD methods
export interface IStorage {
  // Products
  getProducts(): Promise<Product[]>;
  getProductById(id: number): Promise<Product | undefined>;
  getProductsByCategory(category: string): Promise<Product[]>;
  getFeaturedProducts(): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;

  // Categories
  getCategories(): Promise<Category[]>;
  getCategoryById(id: number): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;

  // Orders
  getOrders(): Promise<Order[]>;
  getOrderById(id: number): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: number, status: string): Promise<Order | undefined>;
}

// In-memory implementation
export class MemStorage implements IStorage {
  private products: Map<number, Product>;
  private categories: Map<number, Category>;
  private orders: Map<number, Order>;
  private productId: number;
  private categoryId: number;
  private orderId: number;

  constructor() {
    this.products = new Map();
    this.categories = new Map();
    this.orders = new Map();
    this.productId = 1;
    this.categoryId = 1;
    this.orderId = 1;

    // Initialize with sample categories
    this.initializeCategories();
    // Initialize with sample products
    this.initializeProducts();
  }

  private initializeCategories() {
    const sampleCategories: InsertCategory[] = [
      { name: "Dresses", description: "Elegant dresses for every occasion" },
      { name: "Tops", description: "Stylish tops and blouses" },
      { name: "Accessories", description: "Complete your look with our accessories" },
      { name: "Bottoms", description: "Skirts, pants and shorts" }
    ];

    sampleCategories.forEach(category => this.createCategory(category));
  }

  private initializeProducts() {
    const sampleProducts: InsertProduct[] = [
      {
        name: "Floral Summer Dress",
        description: "A beautiful floral dress perfect for summer days.",
        price: 5999, // $59.99
        imageUrl: "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
        category: "Dresses",
        featured: true,
        inStock: true,
        stockQuantity: 15
      },
      {
        name: "Pink Ruffle Blouse",
        description: "Elegant pink blouse with ruffle details.",
        price: 3499, // $34.99
        imageUrl: "https://images.unsplash.com/photo-1564257555965-35189e7edb9b?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
        category: "Tops",
        featured: true,
        inStock: true,
        stockQuantity: 20
      },
      {
        name: "Pearl Necklace",
        description: "Classic pearl necklace to elevate any outfit.",
        price: 2999, // $29.99
        imageUrl: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
        category: "Accessories",
        featured: false,
        inStock: true,
        stockQuantity: 10
      },
      {
        name: "Pearl Hair Clips Set",
        description: "Set of 3 elegant pearl hair clips.",
        price: 1999, // $19.99
        imageUrl: "https://images.unsplash.com/photo-1589736217826-1b2db5d8c5b4?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
        category: "Accessories",
        featured: true,
        inStock: true,
        stockQuantity: 25
      },
      {
        name: "Silk Rose Scarf",
        description: "Luxurious silk scarf with rose pattern.",
        price: 2499, // $24.99
        imageUrl: "https://images.unsplash.com/photo-1584857097634-2c8a66a156fb?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
        category: "Accessories",
        featured: false,
        inStock: true,
        stockQuantity: 8
      },
      {
        name: "Pleated Midi Skirt",
        description: "Elegant pleated midi skirt in soft pink.",
        price: 4999, // $49.99
        imageUrl: "https://images.unsplash.com/photo-1595155437268-206c739d8ac6?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
        category: "Bottoms",
        featured: true,
        inStock: true,
        stockQuantity: 12
      },
      {
        name: "Lace Evening Dress",
        description: "Stunning lace dress for special occasions.",
        price: 8999, // $89.99
        imageUrl: "https://images.unsplash.com/photo-1566174053879-31528523f8ae?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
        category: "Dresses",
        featured: true,
        inStock: true,
        stockQuantity: 5
      },
      {
        name: "Pastel Cardigan",
        description: "Soft pastel cardigan for a cozy look.",
        price: 3999, // $39.99
        imageUrl: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
        category: "Tops",
        featured: false,
        inStock: true,
        stockQuantity: 15
      },
      {
        name: "Pearl Earrings",
        description: "Elegant pearl earrings for everyday wear.",
        price: 1999, // $19.99
        imageUrl: "https://images.unsplash.com/photo-1617038220319-276d3cfab638?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
        category: "Accessories",
        featured: false,
        inStock: true,
        stockQuantity: 20
      },
      {
        name: "Floral Maxi Dress",
        description: "Beautiful floral maxi dress for summer events.",
        price: 6999, // $69.99
        imageUrl: "https://images.unsplash.com/photo-1623609163859-ca93c959b5e9?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
        category: "Dresses",
        featured: true,
        inStock: true,
        stockQuantity: 8
      },
      {
        name: "Bow Hair Clip",
        description: "Cute bow hair clip for a girly look.",
        price: 1299, // $12.99
        imageUrl: "https://images.unsplash.com/photo-1576871337622-98d48d1cf531?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
        category: "Accessories",
        featured: false,
        inStock: true,
        stockQuantity: 30
      },
      {
        name: "Puff Sleeve Blouse",
        description: "Trendy puff sleeve blouse in white.",
        price: 3699, // $36.99
        imageUrl: "https://images.unsplash.com/photo-1584273143981-41c073dfe8f8?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
        category: "Tops",
        featured: true,
        inStock: true,
        stockQuantity: 10
      }
    ];

    sampleProducts.forEach(product => this.createProduct(product));
  }

  // Product methods
  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProductById(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductsByCategory(category: string): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      (product) => product.category === category
    );
  }

  async getFeaturedProducts(): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      (product) => product.featured
    );
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const id = this.productId++;
    const timestamp = new Date();
    const newProduct: Product = { ...product, id, createdAt: timestamp };
    this.products.set(id, newProduct);
    return newProduct;
  }

  async updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined> {
    const existingProduct = this.products.get(id);
    if (!existingProduct) return undefined;

    const updatedProduct = { ...existingProduct, ...product };
    this.products.set(id, updatedProduct);
    return updatedProduct;
  }

  async deleteProduct(id: number): Promise<boolean> {
    return this.products.delete(id);
  }

  // Category methods
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategoryById(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const id = this.categoryId++;
    const newCategory: Category = { ...category, id };
    this.categories.set(id, newCategory);
    return newCategory;
  }

  // Order methods
  async getOrders(): Promise<Order[]> {
    return Array.from(this.orders.values());
  }

  async getOrderById(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const id = this.orderId++;
    const timestamp = new Date();
    const newOrder: Order = { ...order, id, createdAt: timestamp };
    this.orders.set(id, newOrder);
    return newOrder;
  }

  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const existingOrder = this.orders.get(id);
    if (!existingOrder) return undefined;

    const updatedOrder = { ...existingOrder, status };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }
}

// Export the storage instance
export const storage = new MemStorage();
