interface Animal {
    void eat();
    void makeSound();
    
    default void sleep() {
        System.out.println("The animal is sleeping.");
    }
}

class Dog implements Animal {
    @Override
    public void eat() {
        System.out.println("The dog is eating dog food.");
    }

    @Override
    public void makeSound() {
        System.out.println("The dog barks.");
    }

    public void fetch() {
        System.out.println("The dog is fetching the ball.");
    }
}

class Cat implements Animal {
    @Override
    public void eat() {
        System.out.println("The cat is eating cat food.");
    }

    @Override
    public void makeSound() {
        System.out.println("The cat meows.");
    }

    public void scratch() {
        System.out.println("The cat is scratching the post.");
    }
}

class Bird implements Animal {
    @Override
    public void eat() {
        System.out.println("The bird is eating seeds.");
    }

    @Override
    public void makeSound() {
        System.out.println("The bird chirps.");
    }

    public void fly() {
        System.out.println("The bird is flying.");
    }
}

public class PetShop {
    public static void main(String[] args) {
        Animal dog = new Dog();
        Animal cat = new Cat();
        Animal bird = new Bird();

        System.out.println("Welcome to the Pet Shop!");

        System.out.println("\nDog:");
        dog.eat();
        dog.makeSound();
        dog.sleep();
        ((Dog) dog).fetch();

        System.out.println("\nCat:");
        cat.eat();
        cat.makeSound();
        cat.sleep();
        ((Cat) cat).scratch(); 

        System.out.println("\nBird:");
        bird.eat();
        bird.makeSound();
        bird.sleep();
        ((Bird) bird).fly();
    }
}