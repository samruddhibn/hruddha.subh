import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;
import java.util.Comparator;

public class CollectionDemo {

    public static void main(String[] args) {
        //ArrayList to store and manipulate a list of customer names
        ArrayList<String> customers = new ArrayList<>();
        customers.add("Alice");
        customers.add("Bob");
        customers.add("Charlie");

        System.out.println("Initial customers: " + customers);

        // Manipulate the list: add, remove, update
        customers.add("Diana");
        customers.remove("Bob");
        customers.set(0, "Alicia");

        System.out.println("Updated customers: " + customers);

        // HashMap to store product names and their prices, with lookup
        HashMap<String, Double> products = new HashMap<>();
        products.put("Apple", 0.99);
        products.put("Banana", 0.59);
        products.put("Orange", 1.29);
        products.put("Mango", 1.99);

        System.out.println("\nProducts and prices:");
        for (Map.Entry<String, Double> entry : products.entrySet()) {
            System.out.printf("%s : $%.2f%n", entry.getKey(), entry.getValue());
        }

        // Lookup product price example
        String productToLookup = "Orange";
        if (products.containsKey(productToLookup)) {
            System.out.printf("%nPrice of %s is $%.2f%n", productToLookup, products.get(productToLookup));
        } else {
            System.out.printf("%nProduct %s not found%n", productToLookup);
        }

        //TreeSet to automatically sort products by price
        // Create a product class to hold name and price, override equals & hashCode
        // Use TreeSet with custom comparator sorting by price

        class Product {
            String name;
            double price;

            Product(String name, double price) {
                this.name = name;
                this.price = price;
            }

            @Override
            public String toString() {
                return name + " ($" + String.format("%.2f", price) + ")";
            }

            @Override
            public boolean equals(Object o) {
                if (this == o) return true;
                if (o == null || getClass() != o.getClass()) return false;
                Product product = (Product) o;
                return Double.compare(product.price, price) == 0 && name.equals(product.name);
            }

            @Override
            public int hashCode() {
                return name.hashCode();
            }
        }

        // Comparator to sort by price ascending
        Comparator<Product> priceComparator = Comparator.comparingDouble(p -> p.price);

        TreeSet<Product> sortedProducts = new TreeSet<>(priceComparator);

        // Add products into TreeSet from HashMap
        for (Map.Entry<String, Double> entry : products.entrySet()) {
            sortedProducts.add(new Product(entry.getKey(), entry.getValue()));
        }

        System.out.println("\nProducts sorted by price:");
        for (Product p : sortedProducts) {
            System.out.println(p);
        }
    }
}
