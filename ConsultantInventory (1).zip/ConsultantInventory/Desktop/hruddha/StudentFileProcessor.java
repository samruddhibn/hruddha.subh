import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class StudentFileProcessor {

    public static void main(String[] args) {
        try {
            processStudentRecords("students.txt", "results.txt");
        } catch (IOException e) {
            System.err.println("Error processing files: " + e.getMessage());
        }
    }

    public static void processStudentRecords(String inputFile, String outputFile) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {

            String line;
            while ((line = reader.readLine()) != null) {
                try {
                    String[] parts = line.split(",");
                    if (parts.length != 3) {
                        throw new IllegalArgumentException("Invalid data format");
                    }

                    String studentId = parts[0].trim();
                    String name = parts[1].trim();
                    int marks = parseMarks(parts[2].trim());

                    String grade = calculateGrade(marks);
                    writer.write(String.format("%s,%s,%d,%s%n", studentId, name, marks, grade));

                } catch (IllegalArgumentException | NumberFormatException e) {
                    writer.write("Error in record: " + line + "\n");
                }
            }
        } catch (IOException e) {
            throw new IOException("Unable to read from or write to file: " + e.getMessage(), e);
        }
    }

    private static int parseMarks(String marksStr) {
        try {
            return Integer.parseInt(marksStr);
        } catch (NumberFormatException e) {
            throw new NumberFormatException("Invalid marks format: " + marksStr);
        }
    }

    private static String calculateGrade(int marks) {
        if (marks >= 90 && marks <= 100) {
            return "A";
        } else if (marks >= 80) {
            return "B";
        } else if (marks >= 70) {
            return "C";
        } else if (marks >= 60) {
            return "D";
        } else {
            return "F";
        }
    }
}