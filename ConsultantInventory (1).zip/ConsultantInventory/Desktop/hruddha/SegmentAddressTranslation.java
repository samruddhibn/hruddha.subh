import java.util.Scanner;

public class SegmentAddressTranslation {

    static class Segment {
        int base;
        int limit;

        Segment(int base, int limit) {
            this.base = base;
            this.limit = limit;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter number of segments: ");
        int n = scanner.nextInt();

        Segment[] segmentTable = new Segment[n];

        for (int i = 0; i < n; i++) {
            System.out.printf("Enter base and limit for segment %d: ", i);
            int base = scanner.nextInt();
            int limit = scanner.nextInt();
            segmentTable[i] = new Segment(base, limit);
        }

        System.out.print("Enter segment number: ");
        int segNum = scanner.nextInt();

        System.out.print("Enter offset: ");
        int offset = scanner.nextInt();

        if (segNum < 0 || segNum >= n) {
            System.out.println("Error: Invalid segment number.");
        } else if (offset < 0 || offset >= segmentTable[segNum].limit) {
            System.out.println("Error: Offset exceeds segment limit.");
        } else {
            int physicalAddress = segmentTable[segNum].base + offset;
            System.out.println("Physical address = " + physicalAddress);
        }

        scanner.close();
    }
}