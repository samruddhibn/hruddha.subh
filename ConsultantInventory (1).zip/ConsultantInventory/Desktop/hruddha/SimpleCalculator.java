import java.util.Scanner;

// Custom exception for invalid operations
class InvalidOperationException extends Exception {
    public InvalidOperationException(String message) {
        super(message);
    }
}

public class SimpleCalculator {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double num1 = 0;
        double num2 = 0;
        String operation;

        try {
            // Prompt user for input
            System.out.print("Enter first number: ");
            num1 = getNumberInput(scanner);
            System.out.print("Enter second number: ");
            num2 = getNumberInput(scanner);
            System.out.print("Enter operation (+, -, *, /): ");
            operation = scanner.next();

            // Perform calculation based on the operation
            double result = performOperation(num1, num2, operation);
            System.out.printf("Result: %.2f%n", result);

        } catch (ArithmeticException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Error: Invalid number input! Please enter numeric values.");
        } catch (InvalidOperationException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            System.out.println("Calculation attempt completed.");
            scanner.close();
        }
    }

    // Method to get number input from the user
    private static double getNumberInput(Scanner scanner) throws NumberFormatException {
        String input = scanner.next();
        return Double.parseDouble(input); // This may throw NumberFormatException
    }

    // Method to perform the arithmetic operation
    private static double performOperation(double num1, double num2, String operation) throws InvalidOperationException {
        switch (operation) {
            case "+":
                return num1 + num2;
            case "-":
                return num1 - num2;
            case "*":
                return num1 * num2;
            case "/":
                if (num2 == 0) {
                    throw new ArithmeticException("Cannot divide by zero!");
                }
                return num1 / num2;
            default:
                throw new InvalidOperationException("Invalid operation choice! Please use +, -, *, or /.");
        }
    }
}