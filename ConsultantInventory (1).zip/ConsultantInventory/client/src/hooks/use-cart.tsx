import { 
  createContext, 
  useContext, 
  useState, 
  useEffect, 
  ReactNode 
} from "react";
import { Product } from "@shared/schema";
import { 
  CartItem, 
  loadCart, 
  saveCart, 
  addItemToCart, 
  updateCartItemQuantity, 
  removeCartItem, 
  calculateCartTotal, 
  clearCart as clearCartStorage 
} from "@/lib/cart";
import { useToast } from "@/hooks/use-toast";

interface CartContextType {
  items: CartItem[];
  addItem: (product: Product, quantity: number) => void;
  updateItemQuantity: (productId: number, quantity: number) => void;
  removeItem: (productId: number) => void;
  clearCart: () => void;
  cartTotal: number;
  itemCount: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [cartTotal, setCartTotal] = useState<number>(0);
  const [itemCount, setItemCount] = useState<number>(0);
  const { toast } = useToast();

  // Load cart from localStorage on mount
  useEffect(() => {
    const savedCart = loadCart();
    setItems(savedCart);
  }, []);

  // Update cart total and item count whenever items change
  useEffect(() => {
    setCartTotal(calculateCartTotal(items));
    setItemCount(items.reduce((count, item) => count + item.quantity, 0));
    
    // Save cart to localStorage
    saveCart(items);
  }, [items]);

  // Add item to cart
  const addItem = (product: Product, quantity: number) => {
    if (!product.inStock) {
      toast({
        title: "Product out of stock",
        description: "Sorry, this product is currently out of stock.",
        variant: "destructive",
      });
      return;
    }
    
    if (quantity <= 0) {
      return;
    }

    // Check if adding this quantity would exceed available stock
    const existingItem = items.find(item => item.product.id === product.id);
    const currentQuantity = existingItem ? existingItem.quantity : 0;
    
    if (currentQuantity + quantity > product.stockQuantity) {
      toast({
        title: "Cannot add to cart",
        description: `Sorry, only ${product.stockQuantity} item(s) in stock.`,
        variant: "destructive",
      });
      return;
    }

    setItems(currentItems => addItemToCart(currentItems, product, quantity));
  };

  // Update item quantity
  const updateItemQuantity = (productId: number, quantity: number) => {
    if (quantity <= 0) {
      return;
    }

    const item = items.find(item => item.product.id === productId);
    
    if (item && quantity > item.product.stockQuantity) {
      toast({
        title: "Cannot update quantity",
        description: `Sorry, only ${item.product.stockQuantity} item(s) in stock.`,
        variant: "destructive",
      });
      return;
    }

    setItems(currentItems => 
      updateCartItemQuantity(currentItems, productId, quantity)
    );
  };

  // Remove item from cart
  const removeItem = (productId: number) => {
    setItems(currentItems => removeCartItem(currentItems, productId));
    
    toast({
      title: "Item removed",
      description: "The item has been removed from your cart.",
    });
  };

  // Clear cart
  const clearCart = () => {
    setItems([]);
    clearCartStorage();
  };

  return (
    <CartContext.Provider
      value={{
        items,
        addItem,
        updateItemQuantity,
        removeItem,
        clearCart,
        cartTotal,
        itemCount,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider");
  }
  
  return context;
}
