import { toast } from "@/hooks/use-toast";

// Define the affiliate tracking types
export type AffiliatePlatform = "amazon" | "myntra" | "meesho";

export interface AffiliateClickData {
  productId: number;
  productName: string;
  platform: AffiliatePlatform;
  price: number;
}

// Map of platform emoji icons
const platformEmoji: Record<AffiliatePlatform, string> = {
  amazon: "🛒",
  myntra: "👚",
  meesho: "👗"
};

// Map of cute messages for each platform
const cuteMessages: Record<AffiliatePlatform, string[]> = {
  amazon: [
    "Taking you to Amazon! Happy shopping! ✨",
    "Found a great deal on Amazon! Enjoy! 🎉",
    "Off to Amazon we go! Have fun shopping! 💖"
  ],
  myntra: [
    "Myntra has the perfect style waiting for you! 💅",
    "Fashion alert! Redirecting to Myntra! 👠",
    "Myntra magic coming your way! Look fabulous! ✨"
  ],
  meesho: [
    "Meesho deals just for you! Enjoy! 🎁",
    "Meesho savings incoming! Happy shopping! 💝",
    "Finding you the best prices on Meesho! 🛍️"
  ]
};

// Generate a tracking ID for the click
const generateTrackingId = (): string => {
  return `trk_${Math.random().toString(36).substring(2, 10)}_${Date.now()}`;
};

// Get a random message from the array for the platform
const getRandomMessage = (platform: AffiliatePlatform): string => {
  const messages = cuteMessages[platform];
  const randomIndex = Math.floor(Math.random() * messages.length);
  return messages[randomIndex];
};

// Function to generate affiliate link
export const generateAffiliateLink = (
  platform: AffiliatePlatform, 
  productId: number, 
  productName: string
): string => {
  const trackingId = generateTrackingId();
  
  // Platform-specific affiliate link structures
  switch (platform) {
    case "amazon":
      // Amazon India affiliate link format
      // Replace 'youramazonid-21' with your actual Amazon Associates ID
      return `https://www.amazon.in/dp/B0${productId}XYZ?tag=hruddha-21&tracking=${trackingId}`;
      
    case "myntra":
      // Myntra affiliate link format
      // Replace 'yourMyntraAffiliateID' with your actual Myntra affiliate ID
      const cleanProductName = productName.toLowerCase().replace(/\s+/g, '-');
      return `https://www.myntra.com/${cleanProductName}/${productId}?utm_source=hruddha&utm_medium=affiliate&utm_campaign=productpage&tracking=${trackingId}`;
      
    case "meesho":
      // Meesho affiliate link format
      // Replace 'yourMeeshoAffiliateID' with your actual Meesho affiliate ID
      return `https://www.meesho.com/p/${productId}?utm_source=hruddha&utm_medium=affiliate&utm_campaign=productpage&referrer_code=HRUDDHA&tracking=${trackingId}`;
      
    default:
      // Fallback for any other platform
      return `https://hruddha.com/redirect?to=${platform}&id=${productId}&tracking=${trackingId}`;
  }
};

// Track the click and show a cute notification
export const trackAffiliateClick = (data: AffiliateClickData): string => {
  // Get current timestamp for tracking
  const timestamp = new Date().toISOString();
  
  // In a real application, you would send this data to your backend
  const clickData = {
    ...data,
    timestamp,
    sessionId: localStorage.getItem('session_id') || generateTrackingId(),
    referrer: document.referrer || 'direct',
    device: /Mobi|Android/i.test(navigator.userAgent) ? 'mobile' : 'desktop'
  };
  
  // Log the tracking data to console (in a real app this would be sent to a server)
  console.log("Affiliate click tracked:", clickData);
  
  // Store session ID if not already stored
  if (!localStorage.getItem('session_id')) {
    localStorage.setItem('session_id', clickData.sessionId);
  }
  
  // Generate the affiliate link with platform-specific parameters
  const affiliateLink = generateAffiliateLink(data.platform, data.productId, data.productName);
  
  // Show a platform-specific cute notification with appropriate colors
  let toastClassName = "bg-pink-50 border-pink-200 text-pink-800"; // Default Myntra-like colors
  
  // Set platform-specific colors
  if (data.platform === "amazon") {
    toastClassName = "bg-amber-50 border-amber-200 text-amber-800";
  } else if (data.platform === "meesho") {
    toastClassName = "bg-purple-50 border-purple-200 text-purple-800";
  }
  
  toast({
    title: `${platformEmoji[data.platform]} Affiliate Link Activated!`,
    description: getRandomMessage(data.platform),
    variant: "default",
    className: toastClassName,
  });
  
  return affiliateLink;
};



// Get which platform a product is on based on product ID and/or category
export const getProductPlatform = (productId: number): AffiliatePlatform => {
  // Example of a more sophisticated assignment logic:
  
  // Product ID ranges for different platforms
  // Products 1-5: Amazon
  if (productId >= 1 && productId <= 5) {
    return "amazon";
  }
  
  // Products 6-10: Myntra
  if (productId >= 6 && productId <= 10) {
    return "meesho";
  }
  
  // Products 11-15: Meesho
  if (productId >= 11 && productId <= 15) {
    return "myntra";
  }
  
  // For any other product ID, use a modulo-based assignment as fallback
  if (productId % 3 === 0) return "amazon";
  if (productId % 3 === 1) return "myntra";
  return "meesho";
  
  /* 
   * In a more advanced implementation, you could use product categories:
   * - Fashion accessories: Myntra
   * - Electronics: Amazon
   * - Home goods: Meesho
   * 
   * You would need to pass the category as an additional parameter:
   * export const getProductPlatform = (productId: number, category?: string): AffiliatePlatform => {
   *   if (category === "Accessories") return "myntra";
   *   if (category === "Electronics") return "amazon";
   *   if (category === "Home") return "meesho";
   *   // Default assignment for other categories
   *   return productId % 3 === 0 ? "amazon" : productId % 3 === 1 ? "myntra" : "meesho";
   * }
   */
};