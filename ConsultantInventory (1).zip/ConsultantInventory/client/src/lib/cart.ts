import { Product } from "@shared/schema";

export interface CartItem {
  product: Product;
  quantity: number;
}

// Local storage key for cart
const CART_STORAGE_KEY = 'mushy-couture-cart';

// Load cart from local storage
export const loadCart = (): CartItem[] => {
  if (typeof window === 'undefined') {
    return [];
  }

  try {
    const storedCart = localStorage.getItem(CART_STORAGE_KEY);
    return storedCart ? JSON.parse(storedCart) : [];
  } catch (error) {
    console.error('Error loading cart from localStorage:', error);
    return [];
  }
};

// Save cart to local storage
export const saveCart = (cart: CartItem[]): void => {
  if (typeof window === 'undefined') {
    return;
  }

  try {
    localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
  } catch (error) {
    console.error('Error saving cart to localStorage:', error);
  }
};

// Add item to cart
export const addItemToCart = (
  cart: CartItem[],
  product: Product,
  quantity: number
): CartItem[] => {
  const existingItemIndex = cart.findIndex(
    (item) => item.product.id === product.id
  );

  if (existingItemIndex !== -1) {
    // Item already exists, update quantity
    const updatedCart = [...cart];
    updatedCart[existingItemIndex] = {
      ...updatedCart[existingItemIndex],
      quantity: updatedCart[existingItemIndex].quantity + quantity,
    };
    return updatedCart;
  } else {
    // Add new item
    return [...cart, { product, quantity }];
  }
};

// Update item quantity
export const updateCartItemQuantity = (
  cart: CartItem[],
  productId: number,
  quantity: number
): CartItem[] => {
  return cart.map((item) => {
    if (item.product.id === productId) {
      return { ...item, quantity };
    }
    return item;
  });
};

// Remove item from cart
export const removeCartItem = (
  cart: CartItem[],
  productId: number
): CartItem[] => {
  return cart.filter((item) => item.product.id !== productId);
};

// Calculate cart total (in cents)
export const calculateCartTotal = (cart: CartItem[]): number => {
  return cart.reduce(
    (total, item) => total + item.product.price * item.quantity,
    0
  );
};

// Clear cart
export const clearCart = (): void => {
  if (typeof window === 'undefined') {
    return;
  }

  try {
    localStorage.removeItem(CART_STORAGE_KEY);
  } catch (error) {
    console.error('Error clearing cart from localStorage:', error);
  }
};
