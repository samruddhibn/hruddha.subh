import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import FeaturedProducts from "@/components/FeaturedProducts";
import Newsletter from "@/components/Newsletter";
import { ArrowRight, Check, ShoppingBag } from "lucide-react";
import { BadgeWithIcon } from "@/components/ui/badge-with-icon";

const HomePage = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        {/* Decorative background elements */}
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-pink-50 to-white"></div>
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-pink-100 rounded-full opacity-50 -z-10 blur-3xl"></div>
        <div className="absolute top-20 left-10 w-72 h-72 bg-pink-200 rounded-full opacity-30 -z-10 blur-3xl"></div>
        <div className="absolute bottom-0 right-1/3 w-64 h-64 bg-pink-100 rounded-full opacity-40 -z-10 blur-3xl"></div>
        
        <div className="container mx-auto px-4 py-16 md:py-24">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: "easeOut" }}
              className="relative"
            >
              <div className="flex flex-col relative z-10">
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: 0.3 }}
                >
                  <BadgeWithIcon 
                    variant="pink" 
                    icon={<Check className="h-3 w-3" />}
                    className="shadow-sm"
                  >
                    Curated Affiliate Links Only
                  </BadgeWithIcon>
                </motion.div>
                
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.4 }}
                >
                  <h1 className="mt-4 text-4xl md:text-5xl lg:text-6xl font-bold leading-tight font-['Playfair_Display']">
                    Discover <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-600 to-pink-400">Hruddha</span> Style
                  </h1>
                  
                  <div className="h-1.5 w-28 bg-pink-200 mt-4 rounded-full"></div>
                  
                  <p className="mt-5 text-lg text-gray-700 max-w-lg">
                    Explore our curated collection of elegant fashion from Amazon, Myntra, and Meesho. We help you find the perfect pieces at the best prices!
                  </p>
                  
                  <div className="mt-3 py-2 px-3 bg-pink-50 border-l-4 border-pink-300 rounded-r-md">
                    <p className="text-sm text-pink-600 font-medium flex items-center">
                      <Check className="h-4 w-4 mr-2 text-pink-500" />
                      We only provide product links to Amazon, Myntra & Meesho
                    </p>
                  </div>
                </motion.div>
                
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.6 }}
                  className="mt-8 flex flex-col sm:flex-row gap-4"
                >
                  <Link href="/catalog">
                    <Button className="btn-pink-gradient px-6 py-6 h-auto text-base">
                      Explore Collection
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                  <Link href="/about">
                    <Button variant="outline" className="border-pink-200 text-pink-700 hover:bg-pink-50 px-6 py-6 h-auto text-base">
                      Our Story
                    </Button>
                  </Link>
                </motion.div>
                
                {/* Partner logos */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.5, delay: 0.8 }}
                  className="mt-10 pt-6 border-t border-pink-100"
                >
                  <p className="text-xs text-gray-500 mb-3">SHOP DIRECTLY AT</p>
                  <div className="flex items-center space-x-6">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Amazon_logo.svg/320px-Amazon_logo.svg.png" alt="Amazon" className="h-6 opacity-70 hover:opacity-100 transition-opacity" />
                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/bc/Myntra_Logo.png/320px-Myntra_Logo.png" alt="Myntra" className="h-5 opacity-70 hover:opacity-100 transition-opacity" />
                    <img src="https://seeklogo.com/images/M/meesho-logo-2E20AB3E88-seeklogo.com.png" alt="Meesho" className="h-5 opacity-70 hover:opacity-100 transition-opacity" />
                  </div>
                </motion.div>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="relative mt-6 md:mt-0"
            >
              {/* Main image with decorative elements */}
              <div className="relative mx-auto max-w-md">
                {/* Decorative dotted pattern */}
                <div className="absolute -top-6 -left-6 w-24 h-24 bg-pink-100 rounded-full opacity-70 z-0"></div>
                <div className="absolute -bottom-8 -right-8 w-32 h-32 bg-pink-100 rounded-full opacity-70 z-0"></div>
                
                {/* Main image with frame */}
                <div className="rounded-2xl overflow-hidden shadow-2xl border-4 border-white relative z-10">
                  <img 
                    src="https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?ixlib=rb-1.2.1&auto=format&fit=crop&w=746&q=80" 
                    alt="Fashion model" 
                    className="w-full h-auto object-cover"
                  />
                </div>
                
                {/* Floating elements */}
                <motion.div 
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.6 }}
                  className="absolute -bottom-10 -left-10 bg-white rounded-xl shadow-xl p-4 z-20"
                >
                  <div className="flex items-center">
                    <div className="flex -space-x-2">
                      <img 
                        src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80" 
                        alt="Customer" 
                        className="w-8 h-8 rounded-full border-2 border-white object-cover"
                      />
                      <img 
                        src="https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80" 
                        alt="Customer" 
                        className="w-8 h-8 rounded-full border-2 border-white object-cover"
                      />
                      <img 
                        src="https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80" 
                        alt="Customer" 
                        className="w-8 h-8 rounded-full border-2 border-white object-cover"
                      />
                    </div>
                    <div className="ml-2">
                      <p className="text-xs font-medium text-gray-900">Loved by 2500+ customers</p>
                      <div className="flex text-yellow-400 text-xs mt-1">
                        <span>★</span>
                        <span>★</span>
                        <span>★</span>
                        <span>★</span>
                        <span>★</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
                
                <motion.div 
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.8 }}
                  className="absolute top-6 -right-8 bg-white rounded-full shadow-lg p-3 z-20"
                >
                  <div className="bg-pink-50 rounded-full h-14 w-14 flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-xs font-medium text-pink-600">Up to</p>
                      <p className="text-lg font-bold text-pink-700">50%</p>
                      <p className="text-xs font-medium text-pink-600">OFF</p>
                    </div>
                  </div>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-20 bg-white relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute -left-32 top-20 w-64 h-64 bg-pink-50 rounded-full opacity-60 -z-10 blur-3xl"></div>
        <div className="absolute -right-32 bottom-20 w-64 h-64 bg-pink-50 rounded-full opacity-60 -z-10 blur-3xl"></div>
        
        <div className="container mx-auto px-4">
          <div className="relative text-center mb-16">
            <motion.div
              initial={{ width: 0 }}
              whileInView={{ width: "100%" }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              viewport={{ once: true }}
              className="absolute left-1/2 -translate-x-1/2 top-1/2 -translate-y-1/2 h-2 bg-pink-100 -z-10 max-w-[160px] w-full"
            />
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 font-['Playfair_Display'] inline-block px-4 bg-white">
              Shop by Category
            </h2>
            <p className="mt-4 text-gray-600 max-w-lg mx-auto">
              Explore our wide range of carefully curated feminine fashion pieces from top brands
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                name: "Dresses",
                image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
                count: "215+ Items",
                platform: "Amazon"
              },
              {
                name: "Tops",
                image: "https://images.unsplash.com/photo-1554568218-0f1715e72254?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
                count: "180+ Items",
                platform: "Myntra"
              },
              {
                name: "Accessories",
                image: "https://images.unsplash.com/photo-1621184455862-c163dfb30e0f?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
                count: "95+ Items",
                platform: "Meesho"
              },
              {
                name: "Bottoms",
                image: "https://images.unsplash.com/photo-1583846783214-7229a91b20ed?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
                count: "120+ Items",
                platform: "Amazon"
              }
            ].map((category, index) => (
              <motion.div
                key={category.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="group"
              >
                <Link 
                  href={`/catalog?category=${category.name}`} 
                  className="block overflow-hidden rounded-xl shadow-lg group-hover:shadow-xl transition-all duration-300 bg-white border-4 border-white"
                >
                  <div className="relative aspect-[3/4] overflow-hidden">
                    <img
                      src={category.image}
                      alt={category.name}
                      className="h-full w-full object-cover object-center transition-all duration-500 group-hover:scale-105"
                    />
                    
                    {/* Platform badge */}
                    <div className="absolute top-3 right-3 z-10">
                      <Badge className={`
                        shadow-md backdrop-blur-sm border px-3 py-1
                        ${category.platform === "Amazon" ? "bg-amber-100 text-amber-800 border-amber-200" : 
                          category.platform === "Myntra" ? "bg-pink-100 text-pink-800 border-pink-200" : 
                          "bg-purple-100 text-purple-800 border-purple-200"}
                      `}>
                        {category.platform}
                      </Badge>
                    </div>
                    
                    {/* Gradient overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent group-hover:from-black/60 transition-all duration-300"></div>
                    
                    {/* Text content */}
                    <div className="absolute bottom-0 left-0 right-0 p-6 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                      <h3 className="text-xl font-semibold text-white font-['Playfair_Display']">
                        {category.name}
                      </h3>
                      <div className="flex items-center justify-between mt-2">
                        <p className="text-sm text-white/80 group-hover:text-white transition-colors">
                          {category.count}
                        </p>
                        <span className="text-white text-sm flex items-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                          Shop Now <ArrowRight className="ml-1 h-3.5 w-3.5" />
                        </span>
                      </div>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products Section */}
      <FeaturedProducts />

      {/* Promotion Banner */}
      <section className="relative py-20 overflow-hidden">
        {/* Background decoration */}
        <div className="absolute inset-0 bg-gradient-to-r from-pink-50 to-pink-100 -z-10"></div>
        <div className="absolute top-0 right-0 h-full w-1/2 bg-pink-200 rounded-l-3xl opacity-20 -z-10"></div>
        <div className="absolute -left-16 top-1/4 w-32 h-32 bg-pink-200 rounded-full opacity-30 -z-10 blur-xl"></div>
        <div className="absolute -right-16 bottom-1/4 w-32 h-32 bg-pink-300 rounded-full opacity-20 -z-10 blur-xl"></div>
        
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <motion.div 
              className="order-2 md:order-1"
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <div className="bg-white bg-opacity-80 backdrop-blur-sm p-8 rounded-xl shadow-lg border border-pink-100">
                <Badge className="mb-4 bg-pink-100 text-pink-800 border-pink-200 px-3 py-1">
                  New Arrival
                </Badge>
                
                <h2 className="text-3xl md:text-4xl font-bold leading-tight text-gray-900 font-['Playfair_Display']">
                  Summer Collection <span className="text-pink-600">2025</span>
                </h2>
                
                <div className="h-1 w-24 bg-pink-200 my-4 rounded-full"></div>
                
                <p className="mt-4 text-gray-700">
                  Our new summer collection has arrived! Discover elegant dresses, tops, and accessories perfect for the warm season. Limited quantities available.
                </p>
                
                <ul className="mt-5 space-y-2">
                  <li className="flex items-center text-gray-700">
                    <Check className="h-5 w-5 text-pink-500 mr-2" />
                    <span>Exclusive affiliate deals from top brands</span>
                  </li>
                  <li className="flex items-center text-gray-700">
                    <Check className="h-5 w-5 text-pink-500 mr-2" />
                    <span>Up to 50% off on selected items</span>
                  </li>
                  <li className="flex items-center text-gray-700">
                    <Check className="h-5 w-5 text-pink-500 mr-2" />
                    <span>Direct links to Amazon, Myntra & Meesho</span>
                  </li>
                </ul>
                
                <div className="mt-8">
                  <Link href="/catalog">
                    <Button className="btn-pink-gradient group">
                      <span>Browse Collection</span>
                      <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </Link>
                </div>
              </div>
            </motion.div>
            
            <motion.div 
              className="order-1 md:order-2 relative"
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <div className="relative mx-auto max-w-md">
                {/* Image frame */}
                <div className="rounded-xl overflow-hidden shadow-2xl border-8 border-white relative z-10">
                  <img
                    src="https://images.unsplash.com/photo-1612336307429-8a898d10e223?ixlib=rb-1.2.1&auto=format&fit=crop&w=700&q=80"
                    alt="Summer Collection"
                    className="w-full h-auto"
                  />
                </div>
                
                {/* Floating discount tag */}
                <motion.div
                  initial={{ rotate: -5 }}
                  animate={{ rotate: 5 }}
                  transition={{ duration: 2, repeat: Infinity, repeatType: "reverse" }}
                  className="absolute -top-6 -right-6 bg-white rounded-full shadow-lg p-3 z-20"
                >
                  <div className="bg-gradient-to-r from-pink-500 to-pink-400 rounded-full h-16 w-16 flex items-center justify-center text-white">
                    <div className="text-center">
                      <p className="text-xs font-medium">Up to</p>
                      <p className="text-xl font-bold">50%</p>
                      <p className="text-xs font-medium">OFF</p>
                    </div>
                  </div>
                </motion.div>
                
                {/* Decorative badge */}
                <div className="absolute -bottom-4 -left-4 bg-white rounded-lg shadow-md p-3 z-20">
                  <div className="flex items-center gap-2">
                    <div className="h-10 w-10 rounded-full bg-pink-100 flex items-center justify-center">
                      <ShoppingBag className="h-5 w-5 text-pink-600" />
                    </div>
                    <div>
                      <p className="text-xs font-medium text-gray-700">Limited time</p>
                      <p className="text-sm font-bold text-pink-600">Shop Now</p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 font-['Playfair_Display']">
              What Our Customers Say
            </h2>
            <p className="mt-2 text-gray-600">
              Discover why shoppers love using Hruddha to find the best fashion deals
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: "Sophie K.",
                avatar: "https://images.unsplash.com/photo-1557555187-23d685287bc3?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80",
                quote: "Hruddha provided me with direct links to the best deals on Myntra! I just clicked on the link and completed my purchase on Myntra's website - so easy!",
                location: "Delhi, India"
              },
              {
                name: "Emma T.",
                avatar: "https://images.unsplash.com/photo-1607746882042-944635dfe10e?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80",
                quote: "Hruddha provided direct links to Amazon for my wedding outfit! I just had to click and complete my purchase directly on Amazon's website - no hassle!",
                location: "Mumbai, India"
              },
              {
                name: "Lily M.",
                avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80",
                quote: "Hruddha found amazing Meesho deals and gave me direct links to shop! I clicked straight through to Meesho's website where I completed my purchase - such a time saver!",
                location: "Bangalore, India"
              }
            ].map((testimonial, index) => (
              <div key={index} className="bg-pink-50 p-6 rounded-lg shadow-sm">
                <div className="flex items-center mb-4">
                  <img
                    src={testimonial.avatar}
                    alt={testimonial.name}
                    className="h-12 w-12 rounded-full object-cover mr-4"
                  />
                  <div>
                    <h4 className="font-medium text-gray-900">{testimonial.name}</h4>
                    <p className="text-sm text-gray-500">{testimonial.location}</p>
                  </div>
                </div>
                <div className="flex text-yellow-400 mb-3">
                  <span>★</span>
                  <span>★</span>
                  <span>★</span>
                  <span>★</span>
                  <span>★</span>
                </div>
                <p className="text-gray-600 italic">"{testimonial.quote}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Instagram Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 font-['Playfair_Display']">
              Follow Us on Instagram
            </h2>
            <p className="mt-2 text-gray-600">
              @hruddha.fashion
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2">
            {[
              "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
              "https://images.unsplash.com/photo-1548864497-f5a47f7b3054?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
              "https://images.unsplash.com/photo-1568252748144-5eb254fccd38?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
              "https://images.unsplash.com/photo-1573810030899-fea8369d618f?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
              "https://images.unsplash.com/photo-1556011272-bc056fe0f123?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
              "https://images.unsplash.com/photo-1608228088998-57828365d486?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80"
            ].map((image, index) => (
              <div key={index} className="aspect-square overflow-hidden group cursor-pointer">
                <img
                  src={image}
                  alt={`Instagram post ${index + 1}`}
                  className="h-full w-full object-cover object-center group-hover:scale-110 transition-transform duration-300"
                />
              </div>
            ))}
          </div>
          
          <div className="text-center mt-8">
            <a 
              href="https://instagram.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center text-pink-600 hover:text-pink-700 font-medium"
            >
              View Our Instagram
              <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <Newsletter />
    </div>
  );
};

export default HomePage;
