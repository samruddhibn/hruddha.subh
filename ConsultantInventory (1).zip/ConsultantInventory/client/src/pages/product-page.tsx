import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { Product } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { QuantitySelector } from "@/components/ui/quantity-selector";
import { ProductBadge } from "@/components/ui/product-badge";
import { Heart, ExternalLink, Check, Truck, RefreshCcw, ChevronLeft, ShoppingBag } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import ProductCard from "@/components/ProductCard";
import { trackAffiliateClick, getProductPlatform, AffiliatePlatform } from "@/lib/affiliateService";

const formatPrice = (price: number) => {
  return `₹${(price / 100).toFixed(2)}`;
};

const ProductPage = () => {
  const [match, params] = useRoute<{ id: string }>("/product/:id");
  const { toast } = useToast();
  const [quantity, setQuantity] = useState(1);
  
  const { data: product, isLoading, error } = useQuery<Product>({
    queryKey: [`/api/products/${params?.id}`],
    enabled: !!params?.id,
  });

  const { data: relatedProducts } = useQuery<Product[]>({
    queryKey: ['/api/products'],
    select: (data) => 
      data
        .filter(p => p.category === product?.category && p.id !== product?.id)
        .slice(0, 4),
    enabled: !!product,
  });
  
  // Track affiliate link click and redirect to e-commerce site
  const handleAffiliateClick = () => {
    if (product) {
      // Determine which platform this product is from
      const platform = getProductPlatform(product.id);
      
      // Track the affiliate click and get the generated link
      const affiliateLink = trackAffiliateClick({
        productId: product.id,
        productName: product.name,
        platform,
        price: product.price
      });
      
      // Open the affiliate link in a new tab
      window.open(affiliateLink, '_blank');
    }
  };

  const handleQuantityIncrease = () => {
    setQuantity(prev => prev + 1);
  };

  const handleQuantityDecrease = () => {
    setQuantity(prev => (prev > 1 ? prev - 1 : 1));
  };

  if (error) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold text-gray-900 mb-4">Product Not Found</h1>
        <p className="text-gray-600 mb-6">
          We couldn't find the product you were looking for.
        </p>
        <Link href="/catalog">
          <Button>Back to Catalog</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="bg-white">
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <div className="mb-6">
          <Link href="/catalog" className="flex items-center text-sm text-gray-500 hover:text-pink-700">
            <ChevronLeft className="h-4 w-4 mr-1" />
            Back to catalog
          </Link>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Skeleton className="aspect-square w-full rounded-lg" />
            <div className="space-y-4">
              <Skeleton className="h-8 w-3/4" />
              <Skeleton className="h-6 w-1/4" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-3/4" />
              <div className="pt-6">
                <Skeleton className="h-10 w-full" />
              </div>
            </div>
          </div>
        ) : (
          product && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Product Image */}
                <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden">
                  <img
                    src={product.imageUrl}
                    alt={product.name}
                    className="h-full w-full object-cover object-center"
                  />
                </div>

                {/* Product Details */}
                <div>
                  <div className="mb-2">
                    {product.featured && (
                      <ProductBadge variant="featured">Featured</ProductBadge>
                    )}
                    {!product.inStock && (
                      <ProductBadge variant="sold-out" className="ml-2">
                        Sold Out
                      </ProductBadge>
                    )}
                  </div>

                  <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 font-['Playfair_Display']">
                    {product.name}
                  </h1>

                  <div className="mt-2 flex items-center">
                    <p className="text-xl font-semibold text-gray-900">
                      {formatPrice(product.price)}
                    </p>
                    <span className="ml-2 text-sm text-gray-500">
                      or 4 interest-free payments of {formatPrice(product.price / 4)}
                    </span>
                  </div>

                  <div className="mt-6">
                    <h3 className="text-sm font-medium text-gray-900">Description</h3>
                    <p className="mt-2 text-gray-600 leading-relaxed">
                      {product.description}
                    </p>
                  </div>

                  <div className="mt-6">
                    <div className="flex items-center">
                      <span className="text-sm text-gray-700 mr-2">Category:</span>
                      <Link href={`/catalog?category=${product.category}`} className="text-sm text-pink-600 hover:underline">
                        {product.category}
                      </Link>
                    </div>
                    <div className="flex items-center mt-2">
                      <span className="text-sm text-gray-700 mr-2">Availability:</span>
                      <span className={`text-sm ${product.inStock ? 'text-green-600' : 'text-red-600'}`}>
                        {product.inStock ? 'In Stock' : 'Out of Stock'}
                      </span>
                    </div>
                    <div className="flex items-center mt-2">
                      <span className="text-sm text-gray-700 mr-2">Platform:</span>
                      <span className="text-sm font-medium text-pink-600">
                        {getProductPlatform(product.id) === "amazon" ? "Amazon" : 
                         getProductPlatform(product.id) === "myntra" ? "Myntra" : "Meesho"}
                      </span>
                    </div>
                  </div>

                  <div className="mt-8 flex flex-col space-y-4">
                    <div className="flex items-center">
                      <span className="text-sm font-medium text-gray-900 mr-4">Quantity:</span>
                      <QuantitySelector
                        quantity={quantity}
                        onIncrease={handleQuantityIncrease}
                        onDecrease={handleQuantityDecrease}
                        max={typeof product.stockQuantity === 'number' ? product.stockQuantity : undefined}
                        disabled={!product.inStock}
                      />
                      <span className="ml-4 text-sm text-gray-500">
                        {product.stockQuantity} available
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <Button
                        className="bg-pink-600 hover:bg-pink-700 text-white"
                        disabled={!product.inStock}
                        onClick={handleAffiliateClick}
                      >
                        <ExternalLink className="mr-2 h-4 w-4" />
                        Shop on {getProductPlatform(product.id) === "amazon" ? "Amazon" : 
                               getProductPlatform(product.id) === "myntra" ? "Myntra" : "Meesho"}
                      </Button>
                      <Button variant="outline" className="border-pink-200 text-pink-700 hover:bg-pink-50">
                        <Heart className="mr-2 h-4 w-4" />
                        Save for Later
                      </Button>
                    </div>
                  </div>

                  <div className="mt-8 border-t border-gray-200 pt-6">
                    <div className="space-y-3">
                      <div className="flex items-start">
                        <Check className="h-5 w-5 text-green-500 mt-0.5 mr-2" />
                        <div>
                          <span className="text-sm font-medium text-gray-900">
                            Affiliate Link
                          </span>
                          <p className="text-xs text-gray-500">
                            We earn a small commission when you purchase through our links
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <Truck className="h-5 w-5 text-gray-400 mt-0.5 mr-2" />
                        <div>
                          <span className="text-sm font-medium text-gray-900">
                            Direct Shop Link
                          </span>
                          <p className="text-xs text-gray-500">
                            Shop directly on the retailer's website
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <RefreshCcw className="h-5 w-5 text-gray-400 mt-0.5 mr-2" />
                        <div>
                          <span className="text-sm font-medium text-gray-900">
                            Best Prices
                          </span>
                          <p className="text-xs text-gray-500">
                            We find the best deals so you don't have to
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Product Tabs */}
              <div className="mt-16">
                <Tabs defaultValue="details">
                  <TabsList className="grid w-full grid-cols-3 max-w-md mx-auto">
                    <TabsTrigger value="details">Details</TabsTrigger>
                    <TabsTrigger value="sizing">Sizing</TabsTrigger>
                    <TabsTrigger value="shipping">Shopping Info</TabsTrigger>
                  </TabsList>
                  <TabsContent value="details" className="mt-6">
                    <div className="prose max-w-none">
                      <h3>Product Details</h3>
                      <p>{product.description}</p>
                      <ul>
                        <li>High-quality materials</li>
                        <li>Feminine design elements</li>
                        <li>Perfect for all seasons</li>
                        <li>Versatile styling options</li>
                      </ul>
                    </div>
                  </TabsContent>
                  <TabsContent value="sizing" className="mt-6">
                    <div className="prose max-w-none">
                      <h3>Size Guide</h3>
                      <p>To ensure the perfect fit, please refer to our size guide below:</p>
                      <div className="overflow-x-auto">
                        <table className="min-w-full">
                          <thead>
                            <tr className="border-b">
                              <th className="px-4 py-2 text-left">Size</th>
                              <th className="px-4 py-2 text-left">Bust (in)</th>
                              <th className="px-4 py-2 text-left">Waist (in)</th>
                              <th className="px-4 py-2 text-left">Hips (in)</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr className="border-b">
                              <td className="px-4 py-2">XS</td>
                              <td className="px-4 py-2">32-33</td>
                              <td className="px-4 py-2">24-25</td>
                              <td className="px-4 py-2">34-35</td>
                            </tr>
                            <tr className="border-b">
                              <td className="px-4 py-2">S</td>
                              <td className="px-4 py-2">34-35</td>
                              <td className="px-4 py-2">26-27</td>
                              <td className="px-4 py-2">36-37</td>
                            </tr>
                            <tr className="border-b">
                              <td className="px-4 py-2">M</td>
                              <td className="px-4 py-2">36-37</td>
                              <td className="px-4 py-2">28-29</td>
                              <td className="px-4 py-2">38-39</td>
                            </tr>
                            <tr>
                              <td className="px-4 py-2">L</td>
                              <td className="px-4 py-2">38-40</td>
                              <td className="px-4 py-2">30-32</td>
                              <td className="px-4 py-2">40-42</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </TabsContent>
                  <TabsContent value="shipping" className="mt-6">
                    <div className="prose max-w-none">
                      <h3>How Affiliate Shopping Works</h3>
                      <p>When you click the "Shop on [Platform]" button:</p>
                      <ol>
                        <li>You'll be taken directly to the product on the retailer's website ({getProductPlatform(product.id) === "amazon" ? "Amazon" : 
                         getProductPlatform(product.id) === "myntra" ? "Myntra" : "Meesho"})</li>
                        <li>Complete your purchase directly on their site</li>
                        <li>We earn a small commission at no extra cost to you</li>
                        <li>All shipping, returns, and customer service are handled by the retailer</li>
                      </ol>
                      
                      <h3 className="mt-6">About Our Affiliate Links</h3>
                      <p>Hruddha is a curator of beautiful fashion pieces from various retailers. We don't sell products directly - we just help you find the best deals!</p>
                    </div>
                  </TabsContent>
                </Tabs>
              </div>

              {/* Related Products */}
              {relatedProducts && relatedProducts.length > 0 && (
                <div className="mt-16">
                  <h2 className="text-2xl font-bold text-gray-900 font-['Playfair_Display'] mb-6">
                    You May Also Like
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    {relatedProducts.map(relatedProduct => (
                      <ProductCard key={relatedProduct.id} product={relatedProduct} />
                    ))}
                  </div>
                </div>
              )}
            </>
          )
        )}
      </div>
    </div>
  );
};

export default ProductPage;