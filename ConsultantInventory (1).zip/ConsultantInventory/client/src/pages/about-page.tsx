import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Link } from "wouter";
import { ArrowRight, Heart, CheckCircle, Users, ShoppingBag, Sparkles } from "lucide-react";

const AboutPage = () => {
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative bg-pink-50 overflow-hidden py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-4xl font-bold text-gray-900 leading-tight font-['Playfair_Display'] mb-4">
                Our <span className="text-pink-600">Story</span>
              </h1>
              <p className="text-lg text-gray-600 mb-6">
                MushyCouture was founded with a simple mission: to create beautiful, feminine clothing and accessories that make women feel confident and empowered.
              </p>
              <p className="text-gray-600 mb-8">
                What started as a small boutique in 2015 has grown into a beloved brand, recognized for our commitment to quality, attention to detail, and celebration of feminine style.
              </p>
              <Link href="/catalog">
                <Button className="bg-pink-600 hover:bg-pink-700 text-white">
                  Explore Our Collection
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="rounded-lg overflow-hidden shadow-lg">
                <img 
                  src="https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" 
                  alt="Boutique interior" 
                  className="w-full h-auto"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 font-['Playfair_Display']">
              Our Values
            </h2>
            <p className="mt-2 text-gray-600 max-w-2xl mx-auto">
              At MushyCouture, we believe in creating products that reflect our core values.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: <Heart className="h-10 w-10 text-pink-500" />,
                title: "Passion",
                description: "We're passionate about creating beautiful, high-quality pieces that celebrate femininity."
              },
              {
                icon: <CheckCircle className="h-10 w-10 text-pink-500" />,
                title: "Quality",
                description: "We source the finest materials and pay attention to every detail in our production process."
              },
              {
                icon: <Sparkles className="h-10 w-10 text-pink-500" />,
                title: "Creativity",
                description: "We continuously innovate and create unique designs that stand out."
              },
              {
                icon: <Users className="h-10 w-10 text-pink-500" />,
                title: "Community",
                description: "We value our community of customers and strive to exceed their expectations."
              }
            ].map((value, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white p-6 rounded-lg border border-pink-100 shadow-sm text-center"
              >
                <div className="flex justify-center mb-4">
                  {value.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {value.title}
                </h3>
                <p className="text-gray-600">
                  {value.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Journey */}
      <section className="py-16 bg-pink-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 font-['Playfair_Display']">
              Our Journey
            </h2>
            <p className="mt-2 text-gray-600 max-w-2xl mx-auto">
              From a small dream to a growing brand, here's how our story unfolded.
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto">
            {[
              {
                year: "2015",
                title: "The Beginning",
                description: "MushyCouture started as a small boutique in a cozy corner store with a collection of handpicked items."
              },
              {
                year: "2017",
                title: "Growing Online",
                description: "We launched our online store, bringing our feminine collections to customers nationwide."
              },
              {
                year: "2019",
                title: "Expanding Our Range",
                description: "We expanded our product range to include accessories, creating complete looks for our customers."
              },
              {
                year: "2021",
                title: "Sustainable Practices",
                description: "We committed to more sustainable practices, sourcing eco-friendly materials where possible."
              },
              {
                year: "2023",
                title: "Where We Are Today",
                description: "Today, MushyCouture is a beloved brand with a loyal customer base who share our passion for feminine fashion."
              }
            ].map((milestone, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5 }}
                viewport={{ once: true }}
                className="relative pl-10 pb-10"
              >
                {index !== 4 && (
                  <div className="absolute left-4 top-0 h-full w-0.5 bg-pink-200"></div>
                )}
                <div className="absolute left-0 top-0 h-8 w-8 rounded-full bg-pink-100 border-4 border-pink-300 flex items-center justify-center">
                  <div className="h-3 w-3 rounded-full bg-pink-500"></div>
                </div>
                <div className="pt-1">
                  <span className="text-sm font-bold text-pink-600 block">{milestone.year}</span>
                  <h3 className="text-xl font-semibold text-gray-900 mt-1 mb-2">{milestone.title}</h3>
                  <p className="text-gray-600">{milestone.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 font-['Playfair_Display']">
              Meet Our Team
            </h2>
            <p className="mt-2 text-gray-600 max-w-2xl mx-auto">
              The passionate individuals behind MushyCouture who bring our vision to life.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                name: "Sophia Bennett",
                role: "Founder & Creative Director",
                image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-1.2.1&auto=format&fit=crop&w=634&q=80",
                bio: "Sophia founded MushyCouture with a vision to create feminine pieces that make women feel beautiful and confident."
              },
              {
                name: "Emily Rodriguez",
                role: "Head of Design",
                image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-1.2.1&auto=format&fit=crop&w=634&q=80",
                bio: "With over 10 years in fashion design, Emily brings her expertise and unique vision to our collections."
              },
              {
                name: "Olivia Chen",
                role: "Marketing Manager",
                image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-1.2.1&auto=format&fit=crop&w=634&q=80",
                bio: "Olivia leads our marketing efforts, sharing our story and connecting with our wonderful community."
              }
            ].map((member, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white rounded-lg overflow-hidden shadow-sm"
              >
                <div className="aspect-[3/4] overflow-hidden">
                  <img 
                    src={member.image} 
                    alt={member.name} 
                    className="w-full h-full object-cover object-center"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-gray-900">{member.name}</h3>
                  <p className="text-pink-600 font-medium text-sm mb-3">{member.role}</p>
                  <p className="text-gray-600">{member.bio}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Store Interior */}
      <section className="py-16 bg-pink-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 font-['Playfair_Display']">
              Visit Our Boutique
            </h2>
            <p className="mt-2 text-gray-600 max-w-2xl mx-auto">
              Experience MushyCouture in person at our flagship store.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="grid grid-cols-2 gap-3">
              <div className="aspect-square overflow-hidden rounded-lg">
                <img 
                  src="https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80" 
                  alt="Boutique interior" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="aspect-square overflow-hidden rounded-lg">
                <img 
                  src="https://images.unsplash.com/photo-1604014056132-22a661fd2a23?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80" 
                  alt="Boutique showcase" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="col-span-2 aspect-[2/1] overflow-hidden rounded-lg">
                <img 
                  src="https://images.unsplash.com/photo-1614950298968-89fca10fe2f4?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80" 
                  alt="Boutique storefront" 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            
            <div className="flex flex-col justify-center">
              <h3 className="text-2xl font-semibold text-gray-900 font-['Playfair_Display'] mb-4">
                Experience the MushyCouture Difference
              </h3>
              <p className="text-gray-600 mb-4">
                Visit our boutique to experience our collections in person. Our knowledgeable stylists are ready to help you find the perfect pieces that complement your style.
              </p>
              <div className="space-y-3 mb-6">
                <div className="flex items-start">
                  <div className="flex-shrink-0 h-5 w-5 text-pink-500 mt-0.5">
                    <CheckCircle className="h-5 w-5" />
                  </div>
                  <p className="ml-3 text-gray-600">
                    Personalized styling sessions
                  </p>
                </div>
                <div className="flex items-start">
                  <div className="flex-shrink-0 h-5 w-5 text-pink-500 mt-0.5">
                    <CheckCircle className="h-5 w-5" />
                  </div>
                  <p className="ml-3 text-gray-600">
                    Exclusive in-store collections
                  </p>
                </div>
                <div className="flex items-start">
                  <div className="flex-shrink-0 h-5 w-5 text-pink-500 mt-0.5">
                    <CheckCircle className="h-5 w-5" />
                  </div>
                  <p className="ml-3 text-gray-600">
                    Relaxing atmosphere with refreshments
                  </p>
                </div>
              </div>
              <div className="bg-white p-4 rounded-lg border border-pink-100">
                <h4 className="font-medium text-gray-900 mb-2">Store Hours</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>Monday - Friday</div>
                  <div>10am - 7pm</div>
                  <div>Saturday</div>
                  <div>10am - 6pm</div>
                  <div>Sunday</div>
                  <div>12pm - 5pm</div>
                </div>
                <Separator className="my-3" />
                <p className="text-sm text-gray-600">
                  123 Fashion Avenue, New York, NY 10001
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-pink-100 to-purple-100">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-gray-900 font-['Playfair_Display'] mb-4">
            Ready to Experience MushyCouture?
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto mb-8">
            Browse our collection and find pieces that speak to your feminine style. Join our community of fashion-forward women.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link href="/catalog">
              <Button className="bg-pink-600 hover:bg-pink-700">
                <ShoppingBag className="mr-2 h-4 w-4" />
                Shop Now
              </Button>
            </Link>
            <Link href="/contact">
              <Button variant="outline" className="border-pink-200 text-pink-700 hover:bg-pink-50">
                Contact Us
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;
