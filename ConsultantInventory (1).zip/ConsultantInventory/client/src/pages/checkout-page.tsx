import { useState } from "react";
import { useLocation, Link } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useCart } from "@/hooks/use-cart";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { 
  ArrowLeft, ArrowRight, CheckCircle2, CreditCard, 
  ShieldCheck, Truck, MapPin, ChevronsRight, ShoppingBag 
} from "lucide-react";

// Form schema
const checkoutFormSchema = z.object({
  customerName: z.string().min(2, "Name is required"),
  customerEmail: z.string().email("Invalid email address"),
  customerPhone: z.string().min(10, "Valid phone number is required"),
  shippingAddress: z.string().min(5, "Address is required"),
  shippingCity: z.string().min(2, "City is required"),
  shippingState: z.string().min(2, "State is required"),
  shippingZip: z.string().min(5, "ZIP code is required"),
  shippingCountry: z.string().min(2, "Country is required"),
  saveAddress: z.boolean().default(false),
  paymentMethod: z.enum(["credit-card", "paypal"]),
  cardNumber: z.string().min(16, "Valid card number is required").optional(),
  cardExpiry: z.string().min(5, "Expiration date is required").optional(),
  cardCvv: z.string().min(3, "CVV is required").optional(),
  billingAddressSame: z.boolean().default(true),
  agreeToTerms: z.boolean().refine(val => val === true, {
    message: "You must agree to the terms and conditions",
  })
});

type CheckoutFormValues = z.infer<typeof checkoutFormSchema>;

const formatPrice = (price: number) => {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(price / 100);
};

const CheckoutPage = () => {
  const [, navigate] = useLocation();
  const { items, cartTotal, clearCart } = useCart();
  const { toast } = useToast();
  const [step, setStep] = useState<"shipping" | "payment" | "confirmation">("shipping");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Check if cart is empty and redirect to cart page
  if (items.length === 0) {
    navigate("/cart");
    return null;
  }

  const shippingThreshold = 7500; // $75.00 threshold for free shipping
  const shippingCost = cartTotal >= shippingThreshold ? 0 : 499; // $4.99 shipping cost
  const totalWithShipping = cartTotal + shippingCost;

  const form = useForm<CheckoutFormValues>({
    resolver: zodResolver(checkoutFormSchema),
    defaultValues: {
      customerName: "",
      customerEmail: "",
      customerPhone: "",
      shippingAddress: "",
      shippingCity: "",
      shippingState: "",
      shippingZip: "",
      shippingCountry: "United States",
      saveAddress: false,
      paymentMethod: "credit-card",
      cardNumber: "",
      cardExpiry: "",
      cardCvv: "",
      billingAddressSame: true,
      agreeToTerms: false
    }
  });

  const onSubmit = async (data: CheckoutFormValues) => {
    try {
      setIsSubmitting(true);
      
      // Format order items for API
      const orderItems = items.map(item => ({
        productId: item.product.id,
        productName: item.product.name,
        quantity: item.quantity,
        price: item.product.price
      }));

      // Create order via API
      await apiRequest("POST", "/api/orders", {
        customerName: data.customerName,
        customerEmail: data.customerEmail,
        customerPhone: data.customerPhone,
        shippingAddress: `${data.shippingAddress}, ${data.shippingCity}, ${data.shippingState} ${data.shippingZip}, ${data.shippingCountry}`,
        totalAmount: totalWithShipping,
        status: "pending",
        items: orderItems
      });

      // Move to confirmation step
      setStep("confirmation");
      
      // Show success message
      toast({
        title: "Order placed successfully!",
        description: "Thank you for your purchase.",
      });
      
      // Clear cart after successful order
      clearCart();
    } catch (error) {
      toast({
        title: "Error placing order",
        description: "There was a problem processing your order. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const goToNextStep = () => {
    if (step === "shipping") {
      // Validate shipping fields before proceeding
      const shippingFields = [
        "customerName", "customerEmail", "customerPhone", 
        "shippingAddress", "shippingCity", "shippingState", "shippingZip", "shippingCountry"
      ];
      
      const currentValues = form.getValues();
      const errors: Record<string, any> = {};
      
      shippingFields.forEach(field => {
        if (!currentValues[field as keyof CheckoutFormValues]) {
          errors[field] = true;
        }
      });
      
      // Set errors if any required field is missing
      if (Object.keys(errors).length > 0) {
        shippingFields.forEach(field => {
          if (errors[field]) {
            form.setError(field as any, {
              type: "required",
              message: "This field is required"
            });
          }
        });
        return;
      }
      
      setStep("payment");
    }
  };

  const goToPreviousStep = () => {
    if (step === "payment") {
      setStep("shipping");
    }
  };

  // Content for each step
  const renderStepContent = () => {
    if (step === "confirmation") {
      return (
        <div className="py-12 text-center">
          <div className="flex justify-center mb-6">
            <div className="h-24 w-24 rounded-full bg-green-50 flex items-center justify-center">
              <CheckCircle2 className="h-12 w-12 text-green-500" />
            </div>
          </div>
          <h2 className="text-3xl font-bold text-gray-900 font-['Playfair_Display'] mb-4">
            Thank You for Your Order!
          </h2>
          <p className="text-gray-600 max-w-md mx-auto mb-8">
            Your order has been placed and is being processed. You will receive a confirmation email shortly.
          </p>
          
          <div className="mb-8 max-w-md mx-auto bg-pink-50 rounded-lg p-6 text-left">
            <h3 className="font-medium text-gray-900 mb-2">Order Summary</h3>
            <div className="flex justify-between mb-1">
              <span className="text-gray-600">Order Number:</span>
              <span className="text-gray-900 font-medium">MCS-{Math.floor(10000 + Math.random() * 90000)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Total Amount:</span>
              <span className="text-gray-900 font-medium">{formatPrice(totalWithShipping)}</span>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link href="/">
              <Button className="bg-pink-600 hover:bg-pink-700">
                Continue Shopping
                <ShoppingBag className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            <Link href="/catalog">
              <Button variant="outline" className="border-pink-200 text-pink-700 hover:bg-pink-50">
                Browse Collection
              </Button>
            </Link>
          </div>
        </div>
      );
    }
    
    return (
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Checkout Form */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
            {/* Progress Tabs */}
            <Tabs value={step} className="w-full">
              <TabsList className="grid w-full grid-cols-2 bg-gray-50 rounded-none">
                <TabsTrigger 
                  value="shipping" 
                  className="flex items-center gap-2 data-[state=active]:text-pink-700"
                  onClick={() => step === "payment" && setStep("shipping")}
                >
                  <MapPin className="h-4 w-4" />
                  Shipping
                </TabsTrigger>
                <TabsTrigger 
                  value="payment" 
                  className="flex items-center gap-2 data-[state=active]:text-pink-700"
                  disabled={step !== "payment"}
                >
                  <CreditCard className="h-4 w-4" />
                  Payment
                </TabsTrigger>
              </TabsList>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)}>
                  <TabsContent value="shipping" className="p-6 space-y-6 mt-0">
                    <div>
                      <h2 className="text-xl font-medium text-gray-900 mb-4">Contact Information</h2>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="customerName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Full Name</FormLabel>
                              <FormControl>
                                <Input {...field} className="border-pink-100 focus-visible:ring-pink-200" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="customerEmail"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email Address</FormLabel>
                              <FormControl>
                                <Input {...field} type="email" className="border-pink-100 focus-visible:ring-pink-200" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      <div className="mt-4">
                        <FormField
                          control={form.control}
                          name="customerPhone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Phone Number</FormLabel>
                              <FormControl>
                                <Input {...field} type="tel" className="border-pink-100 focus-visible:ring-pink-200" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h2 className="text-xl font-medium text-gray-900 mb-4">Shipping Address</h2>
                      <div className="space-y-4">
                        <FormField
                          control={form.control}
                          name="shippingAddress"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Street Address</FormLabel>
                              <FormControl>
                                <Input {...field} className="border-pink-100 focus-visible:ring-pink-200" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="shippingCity"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>City</FormLabel>
                                <FormControl>
                                  <Input {...field} className="border-pink-100 focus-visible:ring-pink-200" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="shippingState"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>State / Province</FormLabel>
                                <FormControl>
                                  <Input {...field} className="border-pink-100 focus-visible:ring-pink-200" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="shippingZip"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>ZIP / Postal Code</FormLabel>
                                <FormControl>
                                  <Input {...field} className="border-pink-100 focus-visible:ring-pink-200" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="shippingCountry"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Country</FormLabel>
                                <FormControl>
                                  <Input {...field} className="border-pink-100 focus-visible:ring-pink-200" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={form.control}
                          name="saveAddress"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0 mt-4">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>Save this address for future orders</FormLabel>
                              </div>
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    <div className="mt-6 flex justify-between">
                      <Link href="/cart">
                        <Button 
                          type="button"
                          variant="outline"
                          className="border-pink-200 text-pink-700 hover:bg-pink-50"
                        >
                          <ArrowLeft className="mr-2 h-4 w-4" />
                          Back to Cart
                        </Button>
                      </Link>
                      <Button 
                        type="button"
                        className="bg-pink-600 hover:bg-pink-700"
                        onClick={goToNextStep}
                      >
                        Continue to Payment
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="payment" className="p-6 space-y-6 mt-0">
                    <div>
                      <h2 className="text-xl font-medium text-gray-900 mb-4">Payment Method</h2>
                      <FormField
                        control={form.control}
                        name="paymentMethod"
                        render={({ field }) => (
                          <FormItem>
                            <FormControl>
                              <RadioGroup
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                                className="flex flex-col space-y-3"
                              >
                                <div className="flex items-center space-x-3 bg-white rounded-md border border-pink-100 p-4">
                                  <RadioGroupItem value="credit-card" id="credit-card" className="text-pink-600" />
                                  <label htmlFor="credit-card" className="flex items-center gap-2 cursor-pointer">
                                    <CreditCard className="h-5 w-5 text-pink-600" />
                                    <span className="font-medium">Credit Card</span>
                                  </label>
                                </div>
                                <div className="flex items-center space-x-3 bg-white rounded-md border border-gray-200 p-4">
                                  <RadioGroupItem value="paypal" id="paypal" className="text-pink-600" />
                                  <label htmlFor="paypal" className="flex items-center gap-2 cursor-pointer">
                                    <div className="text-blue-600 font-bold">Pay<span className="text-blue-800">Pal</span></div>
                                    <span className="font-medium">PayPal</span>
                                  </label>
                                </div>
                              </RadioGroup>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    {form.watch("paymentMethod") === "credit-card" && (
                      <div className="space-y-4 bg-pink-50 p-4 rounded-md">
                        <FormField
                          control={form.control}
                          name="cardNumber"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Card Number</FormLabel>
                              <FormControl>
                                <Input 
                                  {...field} 
                                  placeholder="1234 5678 9012 3456" 
                                  className="bg-white border-pink-100 focus-visible:ring-pink-200" 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="cardExpiry"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Expiration Date</FormLabel>
                                <FormControl>
                                  <Input 
                                    {...field} 
                                    placeholder="MM/YY" 
                                    className="bg-white border-pink-100 focus-visible:ring-pink-200" 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="cardCvv"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>CVV</FormLabel>
                                <FormControl>
                                  <Input 
                                    {...field} 
                                    placeholder="123" 
                                    className="bg-white border-pink-100 focus-visible:ring-pink-200" 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={form.control}
                          name="billingAddressSame"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0 mt-4">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>Billing address is the same as shipping address</FormLabel>
                              </div>
                            </FormItem>
                          )}
                        />
                      </div>
                    )}
                    
                    <div className="pt-4">
                      <FormField
                        control={form.control}
                        name="agreeToTerms"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                I agree to the <a href="#" className="text-pink-600 underline">Terms and Conditions</a> and <a href="#" className="text-pink-600 underline">Privacy Policy</a>
                              </FormLabel>
                              <FormMessage />
                            </div>
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="mt-6 flex justify-between">
                      <Button 
                        type="button"
                        variant="outline"
                        className="border-pink-200 text-pink-700 hover:bg-pink-50"
                        onClick={goToPreviousStep}
                      >
                        <ArrowLeft className="mr-2 h-4 w-4" />
                        Back to Shipping
                      </Button>
                      <Button 
                        type="submit"
                        className="bg-pink-600 hover:bg-pink-700"
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? (
                          <>Processing...</>
                        ) : (
                          <>
                            Complete Order
                            <ChevronsRight className="ml-2 h-4 w-4" />
                          </>
                        )}
                      </Button>
                    </div>
                  </TabsContent>
                </form>
              </Form>
            </Tabs>
          </div>
        </div>

        {/* Order Summary */}
        <div>
          <Card className="border-gray-200">
            <CardContent className="p-6">
              <h2 className="text-xl font-medium text-gray-900 mb-4">Order Summary</h2>
              
              <div className="space-y-4 mb-4">
                {items.map((item) => (
                  <div key={item.product.id} className="flex items-center gap-3">
                    <div className="h-14 w-14 flex-shrink-0 rounded-md border border-gray-200 overflow-hidden">
                      <img
                        src={item.product.imageUrl}
                        alt={item.product.name}
                        className="h-full w-full object-cover object-center"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 truncate">
                        {item.product.name}
                      </p>
                      <p className="text-xs text-gray-500">
                        Qty: {item.quantity}
                      </p>
                    </div>
                    <div className="text-sm font-medium text-gray-900">
                      {formatPrice(item.product.price * item.quantity)}
                    </div>
                  </div>
                ))}
              </div>
              
              <Separator className="my-4" />
              
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="text-gray-900 font-medium">{formatPrice(cartTotal)}</span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-gray-600">Shipping</span>
                  <span className="text-gray-900 font-medium">
                    {shippingCost === 0 ? 'Free' : formatPrice(shippingCost)}
                  </span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-gray-900 font-medium">Total</span>
                  <span className="text-gray-900 font-bold">{formatPrice(totalWithShipping)}</span>
                </div>
              </div>
              
              <div className="mt-6 space-y-4">
                <div className="bg-pink-50 p-4 rounded-md">
                  <div className="flex items-start gap-3">
                    <Truck className="h-5 w-5 text-pink-600 mt-0.5" />
                    <div>
                      <h3 className="text-sm font-medium text-gray-900">Shipping Information</h3>
                      <p className="text-xs text-gray-600 mt-1">
                        Free shipping on orders over $75! All orders are processed within 1-2 business days.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-gray-50 p-4 rounded-md">
                  <div className="flex items-start gap-3">
                    <ShieldCheck className="h-5 w-5 text-gray-600 mt-0.5" />
                    <div>
                      <h3 className="text-sm font-medium text-gray-900">Secure Checkout</h3>
                      <p className="text-xs text-gray-600 mt-1">
                        All transactions are secure and encrypted. Your personal data is protected.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-white py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-2xl font-bold text-gray-900 font-['Playfair_Display'] mb-6">
          {step === "confirmation" ? "Order Confirmation" : "Checkout"}
        </h1>
        
        {renderStepContent()}
      </div>
    </div>
  );
};

export default CheckoutPage;
