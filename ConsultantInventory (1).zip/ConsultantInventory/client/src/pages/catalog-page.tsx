import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Product, Category } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Skeleton } from "@/components/ui/skeleton";
import ProductCard from "@/components/ProductCard";
import { Search, SlidersHorizontal, X } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetClose,
} from "@/components/ui/sheet";

const CatalogPage = () => {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split("?")[1]);
  const categoryParam = searchParams.get("category");
  
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(categoryParam);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 10000]);
  const [sortOption, setSortOption] = useState("featured");
  const [searchQuery, setSearchQuery] = useState("");

  const { data: products, isLoading: isLoadingProducts } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });

  const { data: categories, isLoading: isLoadingCategories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  // Filter and sort products
  const filteredProducts = products?.filter(product => {
    let match = true;
    
    // Category filter
    if (selectedCategory) {
      match = match && product.category === selectedCategory;
    }
    
    // Price filter (price stored in cents)
    match = match && 
      product.price >= priceRange[0] && 
      product.price <= priceRange[1];
    
    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      match = match && (
        product.name.toLowerCase().includes(query) ||
        product.description.toLowerCase().includes(query) ||
        product.category.toLowerCase().includes(query)
      );
    }
    
    return match;
  });

  // Sort products
  const sortedProducts = [...(filteredProducts || [])].sort((a, b) => {
    switch (sortOption) {
      case "price-asc":
        return a.price - b.price;
      case "price-desc":
        return b.price - a.price;
      case "newest":
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      case "featured":
      default:
        return b.featured === a.featured ? 0 : b.featured ? 1 : -1;
    }
  });

  // Clear all filters
  const clearFilters = () => {
    setSelectedCategory(null);
    setPriceRange([0, 10000]);
    setSearchQuery("");
    setSortOption("featured");
  };

  // Update category from URL param
  useEffect(() => {
    if (categoryParam) {
      setSelectedCategory(categoryParam);
    }
  }, [categoryParam]);

  return (
    <div className="bg-white">
      <div className="container mx-auto px-4 py-8">
        {/* Page Title */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 font-['Playfair_Display']">
            {selectedCategory ? selectedCategory : "All Products"}
          </h1>
          <p className="mt-2 text-gray-600">
            Explore our collection of feminine fashion pieces
          </p>
        </div>

        {/* Filters and Sorting */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 space-y-4 sm:space-y-0">
          {/* Mobile Filters */}
          <div className="flex items-center space-x-2 sm:hidden">
            <Sheet open={isFilterOpen} onOpenChange={setIsFilterOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" className="gap-2">
                  <SlidersHorizontal className="h-4 w-4" />
                  Filters
                </Button>
              </SheetTrigger>
              <SheetContent side="left">
                <SheetHeader className="mb-4">
                  <SheetTitle>Filters</SheetTitle>
                  <SheetDescription>
                    Refine your product selection
                  </SheetDescription>
                </SheetHeader>
                
                <div className="space-y-6">
                  {/* Mobile Category Filter */}
                  <div>
                    <h3 className="font-medium mb-2">Categories</h3>
                    <div className="space-y-2">
                      {isLoadingCategories ? (
                        <div className="space-y-2">
                          <Skeleton className="h-5 w-full" />
                          <Skeleton className="h-5 w-full" />
                          <Skeleton className="h-5 w-full" />
                        </div>
                      ) : (
                        <>
                          <div className="flex items-center space-x-2">
                            <Checkbox 
                              id="all-categories-mobile" 
                              checked={selectedCategory === null}
                              onCheckedChange={() => setSelectedCategory(null)}
                            />
                            <label htmlFor="all-categories-mobile" className="text-sm">
                              All Categories
                            </label>
                          </div>
                          {categories?.map((category) => (
                            <div key={category.id} className="flex items-center space-x-2">
                              <Checkbox 
                                id={`category-${category.id}-mobile`} 
                                checked={selectedCategory === category.name}
                                onCheckedChange={() => setSelectedCategory(category.name)}
                              />
                              <label htmlFor={`category-${category.id}-mobile`} className="text-sm">
                                {category.name}
                              </label>
                            </div>
                          ))}
                        </>
                      )}
                    </div>
                  </div>

                  {/* Mobile Price Range Filter */}
                  <div>
                    <h3 className="font-medium mb-2">Price Range</h3>
                    <div className="pt-4 px-2">
                      <Slider
                        defaultValue={[priceRange[0], priceRange[1]]}
                        max={10000}
                        step={100}
                        onValueChange={(value) => setPriceRange([value[0], value[1]])}
                      />
                      <div className="flex justify-between mt-2 text-sm text-gray-500">
                        <span>${(priceRange[0] / 100).toFixed(2)}</span>
                        <span>${(priceRange[1] / 100).toFixed(2)}</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-between mt-8">
                  <Button variant="outline" onClick={clearFilters}>
                    Clear All
                  </Button>
                  <SheetClose asChild>
                    <Button>Apply Filters</Button>
                  </SheetClose>
                </div>
              </SheetContent>
            </Sheet>
            
            {selectedCategory && (
              <Button 
                variant="outline" 
                size="sm"
                className="gap-1 text-xs" 
                onClick={() => setSelectedCategory(null)}
              >
                {selectedCategory}
                <X className="h-3 w-3" />
              </Button>
            )}
          </div>
          
          {/* Search Bar */}
          <div className="relative w-full sm:w-64 lg:w-80">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              type="search"
              placeholder="Search products..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          {/* Desktop Sort */}
          <div className="flex items-center space-x-4 w-full sm:w-auto">
            <Select value={sortOption} onValueChange={setSortOption}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="featured">Featured</SelectItem>
                <SelectItem value="newest">Newest</SelectItem>
                <SelectItem value="price-asc">Price: Low to High</SelectItem>
                <SelectItem value="price-desc">Price: High to Low</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-8">
          {/* Desktop Sidebar Filters */}
          <div className="hidden md:block w-full md:w-64 space-y-6">
            {/* Desktop Category Filter */}
            <div>
              <h3 className="font-medium mb-3">Categories</h3>
              <div className="space-y-2">
                {isLoadingCategories ? (
                  <div className="space-y-2">
                    <Skeleton className="h-5 w-full" />
                    <Skeleton className="h-5 w-full" />
                    <Skeleton className="h-5 w-full" />
                  </div>
                ) : (
                  <>
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="all-categories" 
                        checked={selectedCategory === null}
                        onCheckedChange={() => setSelectedCategory(null)}
                      />
                      <label htmlFor="all-categories" className="text-sm">
                        All Categories
                      </label>
                    </div>
                    {categories?.map((category) => (
                      <div key={category.id} className="flex items-center space-x-2">
                        <Checkbox 
                          id={`category-${category.id}`} 
                          checked={selectedCategory === category.name}
                          onCheckedChange={() => setSelectedCategory(category.name)}
                        />
                        <label htmlFor={`category-${category.id}`} className="text-sm">
                          {category.name}
                        </label>
                      </div>
                    ))}
                  </>
                )}
              </div>
            </div>

            {/* Desktop Price Range Filter */}
            <div>
              <h3 className="font-medium mb-3">Price Range</h3>
              <div className="pt-4 px-2">
                <Slider
                  defaultValue={[priceRange[0], priceRange[1]]}
                  max={10000}
                  step={100}
                  onValueChange={(value) => setPriceRange([value[0], value[1]])}
                />
                <div className="flex justify-between mt-2 text-sm text-gray-500">
                  <span>${(priceRange[0] / 100).toFixed(2)}</span>
                  <span>${(priceRange[1] / 100).toFixed(2)}</span>
                </div>
              </div>
            </div>

            {/* Clear Filters */}
            <Button 
              variant="outline" 
              className="w-full text-pink-700 hover:bg-pink-50 hover:text-pink-800"
              onClick={clearFilters}
            >
              Clear All Filters
            </Button>
          </div>

          {/* Product Grid */}
          <div className="flex-1">
            {isLoadingProducts ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-10">
                {Array(9).fill(0).map((_, i) => (
                  <div key={i} className="space-y-4">
                    <Skeleton className="aspect-[3/4] w-full rounded-lg" />
                    <div className="space-y-2">
                      <Skeleton className="h-4 w-3/4" />
                      <Skeleton className="h-4 w-1/2" />
                    </div>
                  </div>
                ))}
              </div>
            ) : sortedProducts?.length === 0 ? (
              <div className="text-center py-12">
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  No products found
                </h3>
                <p className="text-gray-500">
                  Try adjusting your filters or search criteria.
                </p>
                <Button 
                  className="mt-4 bg-pink-600 hover:bg-pink-700"
                  onClick={clearFilters}
                >
                  Clear Filters
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-10">
                {sortedProducts?.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CatalogPage;
