import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { CartItem } from "@/components/ui/cart-item";
import { useCart } from "@/hooks/use-cart";
import { ShoppingBag, ArrowRight, ChevronLeft, Trash2 } from "lucide-react";

const formatPrice = (price: number) => {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(price / 100);
};

const CartPage = () => {
  const { items, updateItemQuantity, removeItem, clearCart, cartTotal } = useCart();
  const [promoCode, setPromoCode] = useState("");
  const [promoError, setPromoError] = useState<string | null>(null);

  const shippingThreshold = 7500; // $75.00 threshold for free shipping
  const shippingCost = cartTotal >= shippingThreshold ? 0 : 499; // $4.99 shipping cost
  const totalWithShipping = cartTotal + shippingCost;

  const handlePromoCodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPromoError("Invalid promotion code. Please try again.");
  };

  const handleClearCart = () => {
    clearCart();
  };

  if (items.length === 0) {
    return (
      <div className="bg-white py-16">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-md mx-auto">
            <div className="flex justify-center mb-6">
              <div className="h-24 w-24 rounded-full bg-pink-50 flex items-center justify-center">
                <ShoppingBag className="h-12 w-12 text-pink-500" />
              </div>
            </div>
            <h1 className="text-2xl font-bold text-gray-900 font-['Playfair_Display'] mb-4">
              Your Cart is Empty
            </h1>
            <p className="text-gray-600 mb-8">
              Looks like you haven't added anything to your cart yet. Browse our collection and find something you'll love!
            </p>
            <Link href="/catalog">
              <Button className="bg-pink-600 hover:bg-pink-700">
                Continue Shopping
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-2xl font-bold text-gray-900 font-['Playfair_Display'] mb-6">
          Shopping Cart
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
              <div className="p-6">
                {items.map((item) => (
                  <CartItem
                    key={item.product.id}
                    item={item}
                    onUpdateQuantity={updateItemQuantity}
                    onRemove={removeItem}
                  />
                ))}
              </div>
              
              <div className="border-t border-gray-200 p-6 flex justify-between items-center">
                <Link href="/catalog" className="flex items-center text-sm text-gray-600 hover:text-pink-700">
                  <ChevronLeft className="h-4 w-4 mr-1" />
                  Continue Shopping
                </Link>
                
                <Button
                  variant="outline"
                  className="text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700"
                  onClick={handleClearCart}
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Clear Cart
                </Button>
              </div>
            </div>
          </div>

          {/* Order Summary */}
          <div>
            <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
              <div className="p-6">
                <h2 className="text-lg font-medium text-gray-900 mb-4">Order Summary</h2>
                
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Subtotal</span>
                    <span className="text-gray-900 font-medium">{formatPrice(cartTotal)}</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-gray-600">Shipping</span>
                    <span className="text-gray-900 font-medium">
                      {shippingCost === 0 ? 'Free' : formatPrice(shippingCost)}
                    </span>
                  </div>
                  
                  {cartTotal < shippingThreshold && (
                    <div className="text-sm text-green-600 italic">
                      Add {formatPrice(shippingThreshold - cartTotal)} more for free shipping!
                    </div>
                  )}
                  
                  <Separator />
                  
                  <div className="flex justify-between">
                    <span className="text-gray-900 font-medium">Total</span>
                    <span className="text-gray-900 font-bold">{formatPrice(totalWithShipping)}</span>
                  </div>
                </div>
                
                <form onSubmit={handlePromoCodeSubmit} className="mt-6">
                  <div className="flex space-x-2">
                    <Input
                      placeholder="Promo code"
                      value={promoCode}
                      onChange={(e) => {
                        setPromoCode(e.target.value);
                        setPromoError(null);
                      }}
                      className="flex-grow border-pink-200 focus-visible:ring-pink-200"
                    />
                    <Button type="submit" variant="outline" className="border-pink-200 text-pink-700 hover:bg-pink-50">
                      Apply
                    </Button>
                  </div>
                  {promoError && (
                    <p className="mt-2 text-xs text-red-600">{promoError}</p>
                  )}
                </form>
                
                <div className="mt-6">
                  <Link href="/checkout">
                    <Button className="w-full bg-pink-600 hover:bg-pink-700">
                      Proceed to Checkout
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
            
            <div className="mt-6 bg-white rounded-lg border border-gray-200 p-6">
              <h3 className="text-sm font-medium text-gray-900 mb-4">Secure Checkout</h3>
              <p className="text-xs text-gray-600">
                We protect your payment information using encryption to provide bank-level security.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartPage;
