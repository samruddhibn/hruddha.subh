import { useState } from "react";
import { Helmet } from "react-helmet";
import { AffiliateBanner } from "@/components/AffiliateBanner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";

const affiliateProducts = [
  {
    id: 1,
    title: "Amazon Deal",
    subtitle: "Limited time offer",
    productImage: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    productName: "Elegant Evening Dress",
    productDescription: "Perfect for special occasions. This evening dress features a stunning silhouette and premium fabrics.",
    originalPrice: 199900,
    discountPrice: 149900,
    discountPercentage: 25,
    affiliateLink: "https://www.amazon.in/dp/B0BPC9WG34",
    isHotDeal: true,
    callToAction: "Buy on Amazon",
    category: "fashion",
    store: "amazon"
  },
  {
    id: 2,
    title: "Myntra Best Seller",
    subtitle: "Customer favorite",
    productImage: "https://images.unsplash.com/photo-1556011272-bc056fe0f123?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    productName: "Pearl Necklace Set",
    productDescription: "Elegant pearl necklace with matching earrings. Perfect for adding a touch of sophistication to any outfit.",
    originalPrice: 129900,
    discountPrice: 99900,
    discountPercentage: 20,
    affiliateLink: "https://www.myntra.com/necklace-sets/zaveri-pearls/zaveri-pearls-off-white-gold-plated-handcrafted-contemporary-necklace--earrings/11228618/buy",
    isHotDeal: false,
    callToAction: "Shop on Myntra",
    category: "accessories",
    store: "myntra"
  },
  {
    id: 3,
    title: "Meesho Flash Sale",
    subtitle: "Ends in 48 hours",
    productImage: "https://images.unsplash.com/photo-1548864497-f5a47f7b3054?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    productName: "Summer Blouse Collection",
    productDescription: "Lightweight and breathable blouses perfect for the summer season. Available in various colors and patterns.",
    originalPrice: 79900,
    discountPrice: 59900,
    discountPercentage: 25,
    affiliateLink: "https://www.meesho.com/s/p/3fu54s",
    isHotDeal: true,
    callToAction: "Get on Meesho",
    category: "fashion",
    store: "meesho"
  },
  {
    id: 4,
    title: "Amazon Popular Choice",
    subtitle: "High-rated product",
    productImage: "https://images.unsplash.com/photo-1544816155-12df9643f363?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    productName: "Designer Handbag",
    productDescription: "Premium designer handbag made from high-quality materials. Spacious interior with multiple compartments.",
    originalPrice: 299900,
    discountPrice: 249900,
    discountPercentage: 15,
    affiliateLink: "https://www.amazon.in/dp/B09MVZSBB3",
    isHotDeal: false,
    callToAction: "Buy on Amazon",
    category: "accessories",
    store: "amazon"
  },
  {
    id: 5,
    title: "Myntra New Arrival",
    subtitle: "Just launched",
    productImage: "https://images.unsplash.com/photo-1573810030899-fea8369d618f?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    productName: "Silk Pajama Set",
    productDescription: "Luxurious silk pajama set for ultimate comfort. Soft, breathable, and elegant design for a restful sleep.",
    originalPrice: 159900,
    discountPrice: 139900,
    discountPercentage: 10,
    affiliateLink: "https://www.myntra.com/night-suits/mast--harbour/mast--harbour-women-solid-night-suit/16407246/buy",
    isHotDeal: false,
    callToAction: "Shop on Myntra",
    category: "lifestyle",
    store: "myntra"
  },
  {
    id: 6,
    title: "Meesho Exclusive Offer",
    subtitle: "Limited stock",
    productImage: "https://images.unsplash.com/photo-1608228088998-57828365d486?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    productName: "Floral Summer Dress",
    productDescription: "Elegant floral dress perfect for summer occasions. High-quality fabric with a feminine design.",
    originalPrice: 99900,
    discountPrice: 75900,
    discountPercentage: 25,
    affiliateLink: "https://www.meesho.com/s/p/3qnc50",
    isHotDeal: true,
    callToAction: "Get on Meesho",
    category: "fashion",
    store: "meesho"
  }
];

const AffiliatePage = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedStore, setSelectedStore] = useState("all");
  
  // Filter products based on search query, category, and store
  const filteredProducts = affiliateProducts.filter(product => {
    const matchesSearch = product.productName.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          product.productDescription.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "all" || product.category === selectedCategory;
    const matchesStore = selectedStore === "all" || product.store === selectedStore;
    
    return matchesSearch && matchesCategory && matchesStore;
  });
  
  return (
    <div className="bg-gray-50 min-h-screen py-12">
      <Helmet>
        <title>Affiliate Products | MushyCouture</title>
        <meta name="description" content="Discover exclusive deals on our curated collection of affiliate products. Find fashion, accessories, and lifestyle items at great prices." />
      </Helmet>
      
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 font-['Playfair_Display']">
            Exclusive Affiliate Deals
          </h1>
          <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
            Discover our hand-picked selection of the best products at exceptional prices. 
            All affiliate purchases help support MushyCouture.
          </p>
        </div>
        
        {/* Search and Filter */}
        <div className="mb-12">
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
              <div className="md:col-span-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <Input
                    type="search"
                    placeholder="Search products..."
                    className="pl-10 border-gray-200"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <p className="text-sm font-medium mb-2">Filter by Category:</p>
                  <Tabs defaultValue="all" onValueChange={setSelectedCategory}>
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="all">All</TabsTrigger>
                      <TabsTrigger value="fashion">Fashion</TabsTrigger>
                      <TabsTrigger value="accessories">Accessories</TabsTrigger>
                    </TabsList>
                  </Tabs>
                </div>
                
                <div>
                  <p className="text-sm font-medium mb-2">Filter by Store:</p>
                  <Tabs defaultValue="all" onValueChange={setSelectedStore}>
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="all">All Stores</TabsTrigger>
                      <TabsTrigger value="amazon">Amazon</TabsTrigger>
                      <TabsTrigger value="myntra">Myntra</TabsTrigger>
                      <TabsTrigger value="meesho">Meesho</TabsTrigger>
                    </TabsList>
                  </Tabs>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Products Grid */}
        <div className="space-y-8">
          {filteredProducts.length > 0 ? (
            filteredProducts.map(product => (
              <AffiliateBanner
                key={product.id}
                title={product.title}
                subtitle={product.subtitle}
                productImage={product.productImage}
                productName={product.productName}
                productDescription={product.productDescription}
                originalPrice={product.originalPrice}
                discountPrice={product.discountPrice}
                discountPercentage={product.discountPercentage}
                affiliateLink={product.affiliateLink}
                isHotDeal={product.isHotDeal}
                callToAction={product.callToAction}
              />
            ))
          ) : (
            <div className="text-center py-12">
              <h3 className="text-lg font-medium text-gray-900">No products found</h3>
              <p className="mt-2 text-gray-600">Try adjusting your search or filter criteria</p>
              <Button 
                className="mt-4 bg-pink-600 hover:bg-pink-700"
                onClick={() => {
                  setSearchQuery("");
                  setSelectedCategory("all");
                  setSelectedStore("all");
                }}
              >
                Reset Filters
              </Button>
            </div>
          )}
        </div>
        
        {/* Affiliate Disclaimer */}
        <div className="mt-16 bg-white p-6 rounded-lg border border-gray-200">
          <h3 className="text-lg font-medium text-gray-900 mb-2">Affiliate Disclosure</h3>
          <p className="text-gray-600 text-sm">
            MushyCouture is a participant in various affiliate marketing programs. This means we may earn a commission 
            when you click on and make a purchase through our links. There is no additional cost to you, and it helps 
            support our website to continue bringing you high-quality content. We only recommend products we believe in 
            and would use ourselves.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AffiliatePage;