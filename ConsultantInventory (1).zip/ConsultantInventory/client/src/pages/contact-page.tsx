import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  Send,
  Instagram,
  Facebook,
  Twitter,
  CheckCircle
} from "lucide-react";

// Contact form schema
const contactFormSchema = z.object({
  name: z.string().min(2, {
    message: "Name must be at least 2 characters.",
  }),
  email: z.string().email({
    message: "Please enter a valid email address.",
  }),
  subject: z.string().min(2, {
    message: "Subject must be at least 2 characters.",
  }),
  message: z.string().min(10, {
    message: "Message must be at least 10 characters.",
  }),
});

type ContactFormValues = z.infer<typeof contactFormSchema>;

const ContactPage = () => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const form = useForm<ContactFormValues>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: "",
      email: "",
      subject: "",
      message: "",
    },
  });

  async function onSubmit(data: ContactFormValues) {
    try {
      setIsSubmitting(true);
      await apiRequest("POST", "/api/contact", data);
      
      setIsSuccess(true);
      form.reset();
      
      toast({
        title: "Message sent successfully",
        description: "We'll get back to you as soon as possible.",
      });
    } catch (error) {
      toast({
        title: "Failed to send message",
        description: "Please try again later.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="bg-white">
      {/* Contact Hero */}
      <section className="relative bg-pink-50 py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-4xl font-bold text-gray-900 font-['Playfair_Display'] mb-4">
                Get in Touch
              </h1>
              <p className="text-lg text-gray-600">
                We'd love to hear from you. Reach out with questions, feedback, or just to say hello!
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Contact Content */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Contact Form */}
            <div className="lg:col-span-2">
              <Card className="border-gray-200">
                <CardContent className="p-6">
                  <h2 className="text-2xl font-semibold text-gray-900 font-['Playfair_Display'] mb-6">
                    Send Us a Message
                  </h2>
                  
                  {isSuccess ? (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="bg-green-50 p-6 rounded-lg text-center"
                    >
                      <div className="flex justify-center mb-4">
                        <div className="h-16 w-16 rounded-full bg-green-100 flex items-center justify-center">
                          <CheckCircle className="h-8 w-8 text-green-600" />
                        </div>
                      </div>
                      <h3 className="text-xl font-medium text-gray-900 mb-2">
                        Message Sent Successfully!
                      </h3>
                      <p className="text-gray-600 mb-4">
                        Thank you for reaching out. We'll get back to you as soon as possible.
                      </p>
                      <Button 
                        onClick={() => setIsSuccess(false)}
                        className="bg-pink-600 hover:bg-pink-700"
                      >
                        Send Another Message
                      </Button>
                    </motion.div>
                  ) : (
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <FormField
                            control={form.control}
                            name="name"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Your Name</FormLabel>
                                <FormControl>
                                  <Input 
                                    placeholder="Jane Smith" 
                                    {...field} 
                                    className="border-pink-100 focus-visible:ring-pink-200"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="email"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Email Address</FormLabel>
                                <FormControl>
                                  <Input 
                                    placeholder="jane@example.com" 
                                    {...field} 
                                    type="email" 
                                    className="border-pink-100 focus-visible:ring-pink-200"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={form.control}
                          name="subject"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Subject</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="How can we help you?" 
                                  {...field} 
                                  className="border-pink-100 focus-visible:ring-pink-200"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="message"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Message</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Tell us more about your inquiry..." 
                                  className="min-h-[150px] resize-none border-pink-100 focus-visible:ring-pink-200" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <Button 
                          type="submit" 
                          disabled={isSubmitting}
                          className="bg-pink-600 hover:bg-pink-700 w-full sm:w-auto"
                        >
                          {isSubmitting ? (
                            "Sending..."
                          ) : (
                            <>
                              <Send className="mr-2 h-4 w-4" />
                              Send Message
                            </>
                          )}
                        </Button>
                      </form>
                    </Form>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Contact Information */}
            <div>
              <Card className="border-gray-200 mb-6">
                <CardContent className="p-6">
                  <h2 className="text-xl font-semibold text-gray-900 font-['Playfair_Display'] mb-6">
                    Contact Information
                  </h2>
                  
                  <div className="space-y-4">
                    <div className="flex items-start">
                      <div className="flex-shrink-0 h-10 w-10 rounded-full bg-pink-100 flex items-center justify-center">
                        <MapPin className="h-5 w-5 text-pink-600" />
                      </div>
                      <div className="ml-4">
                        <h3 className="text-sm font-medium text-gray-900">Our Location</h3>
                        <p className="mt-1 text-sm text-gray-600">
                          123 Fashion Avenue<br />
                          New York, NY 10001
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="flex-shrink-0 h-10 w-10 rounded-full bg-pink-100 flex items-center justify-center">
                        <Phone className="h-5 w-5 text-pink-600" />
                      </div>
                      <div className="ml-4">
                        <h3 className="text-sm font-medium text-gray-900">Phone Number</h3>
                        <p className="mt-1 text-sm text-gray-600">
                          (212) 555-7890
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="flex-shrink-0 h-10 w-10 rounded-full bg-pink-100 flex items-center justify-center">
                        <Mail className="h-5 w-5 text-pink-600" />
                      </div>
                      <div className="ml-4">
                        <h3 className="text-sm font-medium text-gray-900">Email Address</h3>
                        <p className="mt-1 text-sm text-gray-600">
                          hello@mushycouture.com
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="flex-shrink-0 h-10 w-10 rounded-full bg-pink-100 flex items-center justify-center">
                        <Clock className="h-5 w-5 text-pink-600" />
                      </div>
                      <div className="ml-4">
                        <h3 className="text-sm font-medium text-gray-900">Business Hours</h3>
                        <p className="mt-1 text-sm text-gray-600">
                          Monday - Friday: 10am - 7pm<br />
                          Saturday: 10am - 6pm<br />
                          Sunday: 12pm - 5pm
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="border-gray-200">
                <CardContent className="p-6">
                  <h2 className="text-xl font-semibold text-gray-900 font-['Playfair_Display'] mb-6">
                    Follow Us
                  </h2>
                  
                  <div className="flex space-x-4">
                    <a 
                      href="https://instagram.com" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="h-10 w-10 rounded-full bg-pink-100 flex items-center justify-center hover:bg-pink-200 transition-colors"
                    >
                      <Instagram className="h-5 w-5 text-pink-600" />
                    </a>
                    <a 
                      href="https://facebook.com" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="h-10 w-10 rounded-full bg-pink-100 flex items-center justify-center hover:bg-pink-200 transition-colors"
                    >
                      <Facebook className="h-5 w-5 text-pink-600" />
                    </a>
                    <a 
                      href="https://twitter.com" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="h-10 w-10 rounded-full bg-pink-100 flex items-center justify-center hover:bg-pink-200 transition-colors"
                    >
                      <Twitter className="h-5 w-5 text-pink-600" />
                    </a>
                  </div>
                  
                  <div className="mt-6 bg-pink-50 p-4 rounded-lg">
                    <p className="text-sm text-gray-600">
                      Stay updated with our latest collections, promotions, and behind-the-scenes content by following us on social media.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-10">
        <div className="container mx-auto px-4">
          <div className="aspect-[16/7] w-full rounded-lg overflow-hidden shadow-md">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.215175515198!2d-73.99686932422311!3d40.75085087138395!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c259a9b3117469%3A0xd134e199a405a163!2sEmpire%20State%20Building!5e0!3m2!1sen!2sus!4v1666363597309!5m2!1sen!2sus" 
              width="100%" 
              height="100%" 
              style={{ border: 0 }} 
              allowFullScreen={false} 
              loading="lazy" 
              referrerPolicy="no-referrer-when-downgrade"
              title="MushyCouture Store Location"
            ></iframe>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-pink-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 font-['Playfair_Display']">
              Frequently Asked Questions
            </h2>
            <p className="mt-2 text-gray-600 max-w-2xl mx-auto">
              Find answers to common questions about our products and services.
            </p>
          </div>
          
          <div className="max-w-3xl mx-auto">
            <div className="grid gap-6">
              {[
                {
                  question: "What are your shipping options?",
                  answer: "We offer standard shipping (5-7 business days) for $4.99 and express shipping (2-3 business days) for $9.99. Orders over $75 qualify for free standard shipping."
                },
                {
                  question: "What is your return policy?",
                  answer: "We accept returns within 30 days of delivery. Items must be in original condition with tags attached and in original packaging. Please contact our customer service to initiate a return."
                },
                {
                  question: "Do you ship internationally?",
                  answer: "Yes, we ship to select international destinations. International shipping rates and delivery times vary by location. Please check our shipping page for more details."
                },
                {
                  question: "How can I track my order?",
                  answer: "Once your order ships, you'll receive a confirmation email with tracking information. You can also log into your account to check your order status."
                },
                {
                  question: "Do you offer gift wrapping?",
                  answer: "Yes, we offer gift wrapping for $5 per item. You can select this option during checkout and include a personalized message for the recipient."
                }
              ].map((faq, index) => (
                <Card key={index} className="border-pink-100">
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                      {faq.question}
                    </h3>
                    <p className="text-gray-600">
                      {faq.answer}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            <div className="mt-8 text-center">
              <p className="text-gray-600">
                Still have questions? Don't hesitate to <a href="#contact-form" className="text-pink-600 hover:underline">contact us</a>.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;
