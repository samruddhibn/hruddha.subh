import { Link } from "wouter";
import { Product } from "@shared/schema";
import { Heart, ExternalLink, Star, Sparkles, ShoppingBag, ShoppingCart, Tag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { ProductBadge } from "@/components/ui/product-badge";
import { trackAffiliateClick, getProductPlatform } from "@/lib/affiliateService";

interface ProductCardProps {
  product: Product;
}

const formatPrice = (price: number) => {
  return `₹${(price / 100).toFixed(2)}`;
};

const ProductCard = ({ product }: ProductCardProps) => {
  const handleAffiliateClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    // Determine which platform this product is from
    const platform = getProductPlatform(product.id);
    
    // Track the affiliate click and get the generated link
    const affiliateLink = trackAffiliateClick({
      productId: product.id,
      productName: product.name,
      platform,
      price: product.price
    });
    
    // Open the affiliate link in a new tab
    window.open(affiliateLink, '_blank');
  };

  // Get platform-specific information
  const platform = getProductPlatform(product.id);
  const platformName = platform === "amazon" ? "Amazon" : platform === "myntra" ? "Myntra" : "Meesho";
  
  // Get platform-specific icon
  const PlatformIcon = () => {
    switch(platform) {
      case "amazon": return <ShoppingCart className="h-4 w-4" />;
      case "myntra": return <ShoppingBag className="h-4 w-4" />;
      case "meesho": return <Tag className="h-4 w-4" />;
      default: return <ShoppingBag className="h-4 w-4" />;
    }
  };

  // Calculate discount if any
  const hasDiscount = product.featured;
  const originalPrice = hasDiscount ? product.price * 1.2 : null;

  return (
    <motion.div 
      className="product-card group relative touch-manipulation"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      whileTap={{ scale: 0.98 }}
    >
      <div className="product-card-image-container">
        <Link href={`/product/${product.id}`} className="relative block h-full w-full">
          <motion.img
            src={product.imageUrl}
            alt={product.name}
            className="product-card-image"
          />
          
          {/* Platform badge */}
          <div className="absolute top-3 right-3 z-10 bounce-in-animation">
            <Badge className={`
              shadow-md backdrop-blur-sm border px-3 py-1 flex items-center gap-1.5
              ${platform === "amazon" ? "bg-amber-100 text-amber-800 border-amber-200" : 
                platform === "myntra" ? "bg-pink-100 text-pink-800 border-pink-200" : 
                "bg-purple-100 text-purple-800 border-purple-200"}
            `}>
              <PlatformIcon />
              {platformName}
            </Badge>
          </div>
          
          {/* Overlay with gradient */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300" />
          
          {/* Affiliate shopping button */}
          <div className="absolute inset-x-0 bottom-0 p-4 translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
            <button 
              onClick={handleAffiliateClick}
              className="btn-pink-gradient w-full flex items-center justify-center gap-2 py-2.5"
            >
              <span>Shop on {platformName}</span>
              <ExternalLink className="h-4 w-4" />
            </button>
          </div>
          
          {/* Product Badges */}
          <div className="absolute top-3 left-3 flex flex-col gap-2">
            {product.featured && (
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 }}
              >
                <Badge className="bg-gradient-to-r from-amber-500 to-pink-500 text-white px-2.5 py-1 flex items-center gap-1">
                  <Sparkles className="h-3.5 w-3.5" />
                  <span>Hot Deal</span>
                </Badge>
              </motion.div>
            )}
            
            {!product.inStock && (
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
              >
                <ProductBadge variant="sold-out">Sold Out</ProductBadge>
              </motion.div>
            )}
            
            {/* New badge - randomly applied for visual variety */}
            {product.id % 4 === 0 && (
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.15 }}
              >
                <ProductBadge variant="new">New</ProductBadge>
              </motion.div>
            )}
          </div>
        </Link>
      </div>
      
      {/* Product info */}
      <div className="p-3">
        <div className="flex items-start justify-between gap-2">
          <Link href={`/product/${product.id}`} className="group/title">
            <h3 className="font-medium text-gray-900 group-hover/title:text-pink-700 transition-colors line-clamp-2">
              {product.name}
            </h3>
          </Link>
          
          {/* Rating stars - for visual appeal */}
          <div className="flex items-center">
            <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
            <span className="text-xs font-medium text-gray-600 ml-1">
              {4 + (product.id % 11) / 10}
            </span>
          </div>
        </div>
        
        <div className="mt-1 mb-3">
          <p className="text-sm text-gray-500 truncate">{product.category}</p>
        </div>
        
        {/* Price display */}
        <div className="flex items-center">
          {hasDiscount && (
            <span className="price-tag-original">{formatPrice(originalPrice!)}</span>
          )}
          <span className="price-tag price-tag-discount flex items-center">
            {formatPrice(product.price)}
            {hasDiscount && (
              <Badge variant="outline" className="ml-2 text-xs font-normal bg-pink-50 text-pink-600 border-pink-100">
                {Math.round((1 - product.price / originalPrice!) * 100)}% OFF
              </Badge>
            )}
          </span>
        </div>
      </div>
    </motion.div>
  );
};

export default ProductCard;
