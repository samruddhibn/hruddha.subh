import { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface ProductBadgeProps {
  children: ReactNode;
  variant: "new" | "featured" | "sale" | "sold-out";
  className?: string;
}

export function ProductBadge({
  children,
  variant,
  className,
}: ProductBadgeProps) {
  const variantStyles = {
    new: "bg-green-100 text-green-800 border-green-200",
    featured: "bg-pink-100 text-pink-800 border-pink-200",
    sale: "bg-red-100 text-red-800 border-red-200",
    "sold-out": "bg-gray-100 text-gray-800 border-gray-200",
  };

  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium shadow-sm",
        variantStyles[variant],
        className
      )}
    >
      {children}
    </span>
  );
}
