import { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface BadgeWithIconProps {
  children: ReactNode;
  icon: ReactNode;
  className?: string;
  variant?: "default" | "pink" | "secondary" | "outline" | "destructive";
}

export function BadgeWithIcon({
  children,
  icon,
  className,
  variant = "default",
}: BadgeWithIconProps) {
  const variantStyles = {
    default: "bg-primary/10 text-primary border-primary/20",
    pink: "bg-pink-100 text-pink-700 border-pink-200",
    secondary: "bg-secondary/10 text-secondary border-secondary/20",
    outline: "border-border bg-transparent text-foreground",
    destructive: "bg-destructive/10 text-destructive border-destructive/20",
  };

  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium",
        variantStyles[variant],
        className
      )}
    >
      <span className="mr-1">{icon}</span>
      {children}
    </span>
  );
}
