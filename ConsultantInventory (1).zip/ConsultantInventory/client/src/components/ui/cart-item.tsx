import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { QuantitySelector } from "@/components/ui/quantity-selector";
import { CartItem as CartItemType } from "@/lib/cart";
import { Link } from "wouter";

interface CartItemProps {
  item: CartItemType;
  onUpdateQuantity: (id: number, quantity: number) => void;
  onRemove: (id: number) => void;
}

const formatPrice = (price: number) => {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(price / 100);
};

export function CartItem({ item, onUpdateQuantity, onRemove }: CartItemProps) {
  const handleIncrease = () => {
    onUpdateQuantity(item.product.id, item.quantity + 1);
  };

  const handleDecrease = () => {
    if (item.quantity > 1) {
      onUpdateQuantity(item.product.id, item.quantity - 1);
    }
  };

  const handleRemove = () => {
    onRemove(item.product.id);
  };

  return (
    <div className="flex items-center py-6 border-b border-gray-200">
      <div className="flex-shrink-0 w-24 h-24 border border-gray-200 rounded-md overflow-hidden">
        <img
          src={item.product.imageUrl}
          alt={item.product.name}
          className="w-full h-full object-cover object-center"
        />
      </div>

      <div className="ml-4 flex-1 flex flex-col">
        <div className="flex justify-between">
          <div>
            <h3 className="text-sm font-medium text-gray-900">
              <Link href={`/product/${item.product.id}`} className="hover:text-pink-700 transition-colors">
                {item.product.name}
              </Link>
            </h3>
            <p className="mt-1 text-sm text-gray-500">{item.product.category}</p>
          </div>
          <p className="text-sm font-medium text-gray-900">
            {formatPrice(item.product.price)}
          </p>
        </div>

        <div className="flex-1 flex items-end justify-between mt-4">
          <QuantitySelector
            quantity={item.quantity}
            onIncrease={handleIncrease}
            onDecrease={handleDecrease}
          />
          <Button
            variant="ghost"
            size="icon"
            className="text-gray-400 hover:text-gray-500"
            onClick={handleRemove}
          >
            <X className="h-5 w-5" />
            <span className="sr-only">Remove</span>
          </Button>
        </div>
      </div>
    </div>
  );
}
