import { Button } from "@/components/ui/button";
import { Minus, Plus } from "lucide-react";

interface QuantitySelectorProps {
  quantity: number;
  onIncrease: () => void;
  onDecrease: () => void;
  min?: number;
  max?: number;
  disabled?: boolean;
}

export function QuantitySelector({
  quantity,
  onIncrease,
  onDecrease,
  min = 1,
  max = 99,
  disabled = false,
}: QuantitySelectorProps) {
  const canDecrease = !disabled && quantity > min;
  const canIncrease = !disabled && quantity < max;

  return (
    <div className="flex items-center border border-gray-200 rounded-md">
      <Button
        variant="ghost"
        size="icon"
        className="h-8 w-8 rounded-r-none text-gray-500"
        onClick={onDecrease}
        disabled={!canDecrease}
      >
        <Minus className="h-3 w-3" />
      </Button>
      <div className="w-12 h-8 flex items-center justify-center border-x border-gray-200 text-sm">
        {quantity}
      </div>
      <Button
        variant="ghost"
        size="icon"
        className="h-8 w-8 rounded-l-none text-gray-500"
        onClick={onIncrease}
        disabled={!canIncrease}
      >
        <Plus className="h-3 w-3" />
      </Button>
    </div>
  );
}
