import { useQuery } from "@tanstack/react-query";
import ProductCard from "./ProductCard";
import { Product } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowRight, ChevronLeft, ChevronRight } from "lucide-react";
import { Link } from "wouter";
import { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { 
  Carousel, 
  CarouselContent, 
  CarouselItem, 
  CarouselNext, 
  CarouselPrevious 
} from "@/components/ui/carousel";

const FeaturedProducts = () => {
  const { data: products, isLoading, error } = useQuery<Product[]>({
    queryKey: ['/api/products/featured'],
  });

  if (error) {
    return (
      <div className="py-16 text-center">
        <p className="text-red-500">Failed to load featured products. Please try again later.</p>
      </div>
    );
  }

  return (
    <section className="py-16 bg-gradient-to-b from-white to-pink-50">
      <div className="container mx-auto px-4">
        <div className="relative mb-16">
          {/* Decorative elements */}
          <div className="absolute -top-6 left-0 w-24 h-24 bg-pink-100 rounded-full opacity-50 -z-10 blur-xl"></div>
          <div className="absolute top-10 right-10 w-16 h-16 bg-pink-200 rounded-full opacity-30 -z-10 blur-lg"></div>
          
          <div className="text-center relative">
            <div className="inline-block relative">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: "100%" }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className="absolute bottom-2 left-0 h-3 bg-pink-200 opacity-50 -z-10"
              />
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 font-['Playfair_Display'] mb-2">
                Featured Collection
              </h2>
            </div>
            <p className="mt-2 text-gray-600 max-w-2xl mx-auto">
              Discover our most popular and trendy items carefully selected for you.
            </p>
            
            <div className="mt-6 flex justify-center">
              <Link href="/catalog">
                <Button 
                  className="btn-pink-gradient"
                >
                  View All Products
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {isLoading ? (
          // Loading skeleton
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-6 gap-y-10">
            {Array(4).fill(0).map((_, i) => (
              <div key={i} className="space-y-4">
                <Skeleton className="aspect-[3/4] w-full rounded-lg" />
                <div className="space-y-2">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <>
            {/* Mobile Carousel (only shown on mobile/small screens) */}
            <div className="block md:hidden">
              <div className="relative">
                <motion.div className="absolute -z-10 top-1/3 left-1/4 w-32 h-32 rounded-full bg-pink-100 blur-xl opacity-60" />
                <motion.div className="absolute -z-10 top-1/2 right-1/4 w-24 h-24 rounded-full bg-pink-200 blur-xl opacity-50" />
                
                <Carousel 
                  className="w-full mx-auto" 
                  opts={{
                    align: "start",
                    loop: true,
                  }}
                >
                  <CarouselContent className="-ml-1">
                    {products?.slice(0, 8).map((product) => (
                      <CarouselItem key={product.id} className="pl-1 basis-full sm:basis-1/2">
                        <div className="p-1">
                          <ProductCard product={product} />
                        </div>
                      </CarouselItem>
                    ))}
                  </CarouselContent>
                  <div className="flex justify-center mt-6 gap-3">
                    <CarouselPrevious className="relative static translate-y-0 translate-x-0 bg-pink-100 hover:bg-pink-200 border-pink-200 text-pink-600 h-10 w-10 rounded-full" />
                    <CarouselNext className="relative static translate-y-0 translate-x-0 bg-pink-100 hover:bg-pink-200 border-pink-200 text-pink-600 h-10 w-10 rounded-full" />
                  </div>
                </Carousel>
                
                {/* Swipe instruction for mobile */}
                <div className="mt-4 text-center text-sm text-pink-600 font-medium flex items-center justify-center gap-2">
                  <motion.div 
                    animate={{ x: [-5, 5, -5] }} 
                    transition={{ repeat: Infinity, duration: 1.5 }}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </motion.div>
                  <span>Swipe to explore more</span>
                  <motion.div 
                    animate={{ x: [5, -5, 5] }} 
                    transition={{ repeat: Infinity, duration: 1.5 }}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </motion.div>
                </div>
              </div>
            </div>
            
            {/* Desktop Grid View */}
            <div className="hidden md:grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-6 gap-y-10 relative">
              {/* Decorative elements for desktop */}
              <motion.div className="absolute -z-10 top-1/4 left-0 w-48 h-48 rounded-full bg-pink-50 blur-3xl opacity-60" />
              <motion.div className="absolute -z-10 bottom-1/3 right-10 w-40 h-40 rounded-full bg-pink-100 blur-2xl opacity-50" />
              
              {products?.slice(0, 8).map((product, index) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                >
                  <ProductCard product={product} />
                </motion.div>
              ))}
            </div>
          </>
        )}
      </div>
    </section>
  );
};

export default FeaturedProducts;
