import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Search, ShoppingBag, Menu, Heart, X } from "lucide-react";
import { useCart } from "@/hooks/use-cart";

const Navbar = () => {
  const [location] = useLocation();
  const { items } = useCart();
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  const totalItems = items.reduce((total, item) => total + item.quantity, 0);

  const navLinks = [
    { name: "Home", path: "/" },
    { name: "Shop", path: "/catalog" },
    { name: "Deals", path: "/affiliate-deals" },
    { name: "About", path: "/about" },
    { name: "Contact", path: "/contact" },
  ];

  return (
    <header className="navbar-glass sticky top-0 z-50">
      {/* Top banner for promotions */}
      <div className="bg-gradient-to-r from-pink-500 to-pink-400 text-white text-xs sm:text-sm text-center py-1.5 px-4">
        <p className="font-medium">Discover amazing products across Amazon, Myntra & Meesho with affiliate links</p>
      </div>
      
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Mobile Menu Toggle */}
          <Sheet>
            <SheetTrigger asChild className="lg:hidden">
              <Button variant="ghost" size="icon" aria-label="Menu" className="text-pink-700 hover:bg-pink-50">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[280px] sm:w-[350px] bg-white">
              <div className="flex flex-col h-full">
                <div className="py-6 text-center">
                  <h2 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-600 to-pink-400 font-['Playfair_Display']">
                    Hruddha
                  </h2>
                  <p className="text-sm text-gray-500 mt-1">Affiliate Fashion Store</p>
                </div>
                <nav className="flex-1">
                  <ul className="space-y-2">
                    {navLinks.map((link) => (
                      <li key={link.path}>
                        <Link 
                          href={link.path} 
                          className={`block px-4 py-3 text-lg rounded-md transition-colors ${
                            location === link.path
                              ? "bg-pink-50 text-pink-700 font-medium"
                              : "text-gray-700 hover:bg-pink-50 hover:text-pink-700"
                          }`}
                        >
                          {link.name}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </nav>
                <div className="py-6 border-t border-pink-100">
                  <Button className="btn-pink-gradient w-full">
                    Browse Collection
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>

          {/* Logo */}
          <div className="flex items-center">
            <Link href="/" className="group">
              <h1 className="text-2xl md:text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-600 to-pink-400 font-['Playfair_Display'] group-hover:from-pink-500 group-hover:to-pink-300 transition-all duration-300">
                Hruddha
              </h1>
              <p className="text-[10px] md:text-xs text-gray-500 -mt-1 text-center">Affiliate Fashion Store</p>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-1">
            {navLinks.map((link) => (
              <Link 
                key={link.path} 
                href={link.path}
                className={`px-4 py-2 text-sm font-medium rounded-md transition-all duration-200 hover:bg-pink-50 hover:text-pink-700 ${
                  location === link.path
                    ? "text-pink-700 bg-pink-50"
                    : "text-gray-600"
                }`}
              >
                {link.name}
              </Link>
            ))}
          </nav>

          {/* Right Icons */}
          <div className="flex items-center space-x-1 sm:space-x-2">
            {isSearchOpen ? (
              <div className="flex items-center gap-2 bg-pink-50 px-3 py-1 rounded-full border border-pink-100 shadow-sm">
                <Input
                  type="search"
                  placeholder="Search products..."
                  className="border-none bg-transparent h-8 focus-visible:ring-0 focus-visible:ring-offset-0 w-[150px] sm:w-[200px] text-sm"
                  autoFocus
                />
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8 text-pink-600 hover:bg-pink-100 rounded-full"
                  onClick={() => setIsSearchOpen(false)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-gray-600 hover:text-pink-700 hover:bg-pink-50 rounded-full" 
                onClick={() => setIsSearchOpen(true)}
              >
                <Search className="h-5 w-5" />
              </Button>
            )}
            
            <Button variant="ghost" size="icon" className="text-gray-600 hover:text-pink-700 hover:bg-pink-50 rounded-full">
              <Heart className="h-5 w-5" />
            </Button>
            
            <Link href="/cart" className="relative">
              <Button variant="ghost" size="icon" className="text-gray-600 hover:text-pink-700 hover:bg-pink-50 rounded-full">
                <ShoppingBag className="h-5 w-5" />
              </Button>
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 bg-gradient-to-r from-pink-500 to-pink-400 text-white text-[10px] font-bold rounded-full h-5 w-5 flex items-center justify-center shadow-sm">
                  {totalItems}
                </span>
              )}
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
