import { Button } from "@/components/ui/button";
import { BadgeWithIcon } from "@/components/ui/badge-with-icon";
import { Star, Tag, Zap, ExternalLink, ChevronLeft, ChevronRight } from "lucide-react";
import { motion } from "framer-motion";
import { useRef, useState, useEffect } from "react";
import { useIsMobile } from "@/hooks/use-mobile";

interface AffiliateBannerProps {
  title?: string;
  subtitle?: string;
  productImage?: string;
  productName?: string;
  productDescription?: string;
  originalPrice?: number;
  discountPrice?: number;
  discountPercentage?: number;
  affiliateLink?: string;
  isHotDeal?: boolean;
  callToAction?: string;
}

export function AffiliateBanner({
  title = "Exclusive Deal",
  subtitle = "Limited time offer",
  productImage = "https://images.unsplash.com/photo-1608228088998-57828365d486?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
  productName = "Floral Summer Dress",
  productDescription = "Elegant floral dress perfect for summer occasions. High-quality fabric with a feminine design.",
  originalPrice = 9999,
  discountPrice = 7599,
  discountPercentage = 25,
  affiliateLink = "https://example.com/affiliate",
  isHotDeal = true,
  callToAction = "Shop Now"
}: AffiliateBannerProps) {
  const isMobile = useIsMobile();
  const [currentSlide, setCurrentSlide] = useState(0);
  const [startX, setStartX] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const bannerRef = useRef<HTMLDivElement>(null);
  
  // Array of sample images for the mobile carousel
  const images = [
    productImage,
    "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    "https://images.unsplash.com/photo-1554568218-0f1715e72254?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80"
  ];

  // Format prices to display in rupees
  const formatPrice = (price: number) => {
    return `₹${(price / 100).toFixed(2)}`;
  };
  
  // Handle swipe gestures
  const handleTouchStart = (e: React.TouchEvent) => {
    setStartX(e.touches[0].clientX);
    setIsDragging(true);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging) return;
    const currentX = e.touches[0].clientX;
    const diff = startX - currentX;

    // Detect swipe direction
    if (Math.abs(diff) > 50) {
      if (diff > 0) {
        // Swipe left - next slide
        setCurrentSlide(prev => (prev < images.length - 1 ? prev + 1 : 0));
      } else {
        // Swipe right - previous slide
        setCurrentSlide(prev => (prev > 0 ? prev - 1 : images.length - 1));
      }
      setIsDragging(false);
    }
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
  };
  
  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };
  
  const nextSlide = () => {
    setCurrentSlide(prev => (prev < images.length - 1 ? prev + 1 : 0));
  };
  
  const prevSlide = () => {
    setCurrentSlide(prev => (prev > 0 ? prev - 1 : images.length - 1));
  };

  return (
    <motion.div 
      className="border border-pink-200 rounded-lg overflow-hidden bg-white shadow-md hover:shadow-xl transition-all duration-300"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.01 }}
      transition={{ duration: 0.4 }}
      ref={bannerRef}
    >
      <div className="flex flex-col md:flex-row">
        {/* Mobile Carousel View */}
        {isMobile ? (
          <div 
            className="relative w-full"
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
          >
            <div className="overflow-hidden relative">
              <motion.div 
                className="flex"
                animate={{ x: `-${currentSlide * 100}%` }}
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
              >
                {images.map((img, index) => (
                  <div key={index} className="min-w-full aspect-[3/4]">
                    <img 
                      src={img} 
                      alt={`${productName} - view ${index + 1}`}
                      className="w-full h-full object-cover object-center"
                    />
                  </div>
                ))}
              </motion.div>
              
              {/* Navigation Buttons */}
              <div className="absolute z-10 inset-x-0 bottom-4 flex justify-center gap-1">
                {images.map((_, index) => (
                  <motion.button
                    key={index}
                    className={`w-2 h-2 rounded-full ${currentSlide === index ? 'bg-white' : 'bg-white/50'}`}
                    onClick={() => goToSlide(index)}
                    whileHover={{ scale: 1.5 }}
                  />
                ))}
              </div>
              
              {/* Discount Badge */}
              {discountPercentage > 0 && (
                <motion.div 
                  className="absolute top-4 left-4 bg-pink-600 text-white px-2 py-1 rounded-md text-sm font-bold"
                  initial={{ opacity: 0, scale: 0.5 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.2 }}
                >
                  {discountPercentage}% OFF
                </motion.div>
              )}
              
              {/* Navigation Arrows */}
              <button 
                className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/70 rounded-full p-1 backdrop-blur-sm"
                onClick={prevSlide}
              >
                <ChevronLeft className="h-5 w-5 text-pink-700" />
              </button>
              <button 
                className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/70 rounded-full p-1 backdrop-blur-sm"
                onClick={nextSlide}
              >
                <ChevronRight className="h-5 w-5 text-pink-700" />
              </button>
            </div>
          </div>
        ) : (
          // Desktop View
          <div className="md:w-1/3 relative overflow-hidden">
            <motion.img 
              src={productImage} 
              alt={productName}
              className="w-full h-full object-cover object-center aspect-[3/4] md:aspect-auto"
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.4 }}
            />
            {discountPercentage > 0 && (
              <motion.div 
                className="absolute top-4 left-4 bg-pink-600 text-white px-2 py-1 rounded-md text-sm font-bold"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2 }}
              >
                {discountPercentage}% OFF
              </motion.div>
            )}
          </div>
        )}
        
        {/* Product Details */}
        <motion.div 
          className="md:w-2/3 p-6 flex flex-col"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1, duration: 0.3 }}
        >
          <div className="flex justify-between items-start mb-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
              <p className="text-sm text-gray-500">{subtitle}</p>
            </div>
            {isHotDeal && (
              <motion.div
                initial={{ x: 20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.3 }}
              >
                <BadgeWithIcon 
                  icon={<Zap className="h-3 w-3" />}
                  variant="pink"
                >
                  Hot Deal
                </BadgeWithIcon>
              </motion.div>
            )}
          </div>
          
          <motion.h2 
            className="text-xl font-bold text-gray-900 font-['Playfair_Display'] mb-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            {productName}
          </motion.h2>
          <p className="text-gray-600 mb-4">{productDescription}</p>
          
          <motion.div 
            className="flex items-center mb-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            <div className="flex text-yellow-400 mr-2">
              <Star className="h-4 w-4 fill-current" />
              <Star className="h-4 w-4 fill-current" />
              <Star className="h-4 w-4 fill-current" />
              <Star className="h-4 w-4 fill-current" />
              <Star className="h-4 w-4 fill-current" />
            </div>
            <span className="text-sm text-gray-500">5.0 (120+ reviews)</span>
          </motion.div>
          
          <motion.div 
            className="flex items-center mb-6"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <motion.span 
              className="text-2xl font-bold text-pink-600 mr-3"
              whileHover={{ scale: 1.05 }}
            >
              {formatPrice(discountPrice)}
            </motion.span>
            {originalPrice > discountPrice && (
              <span className="text-lg text-gray-400 line-through">{formatPrice(originalPrice)}</span>
            )}
          </motion.div>
          
          <motion.div 
            className="mt-auto flex flex-col sm:flex-row gap-3"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <motion.a 
              href={affiliateLink} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="w-full sm:w-auto"
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
            >
              <Button className="w-full bg-pink-600 hover:bg-pink-700">
                {callToAction}
                <ExternalLink className="ml-2 h-4 w-4" />
              </Button>
            </motion.a>
            <motion.a 
              href={affiliateLink} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="w-full sm:w-auto"
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
            >
              <Button variant="outline" className="w-full border-pink-200 text-pink-700 hover:bg-pink-50">
                <Tag className="mr-2 h-4 w-4" />
                See More Deals
              </Button>
            </motion.a>
          </motion.div>
        </motion.div>
      </div>
    </motion.div>
  );
}