import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Facebook, Instagram, Linkedin, Twitter } from "lucide-react";
import { z } from "zod";
import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";

const Footer = () => {
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      setIsSubmitting(true);
      
      // Validate email
      const emailSchema = z.string().email("Please enter a valid email address");
      emailSchema.parse(email);
      
      // Submit to API
      await apiRequest("POST", "/api/newsletter/subscribe", { email });
      
      toast({
        title: "Subscribed!",
        description: "Thank you for subscribing to our newsletter.",
        variant: "default",
      });
      
      setEmail("");
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast({
          title: "Invalid email",
          description: error.errors[0].message,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Subscription failed",
          description: "Please try again later.",
          variant: "destructive",
        });
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <footer className="bg-pink-50 pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div>
            <h3 className="font-['Playfair_Display'] text-2xl font-bold text-pink-700 mb-4">
              Hruddha
            </h3>
            <p className="text-gray-600 mb-4">
              Discover elegant and feminine fashion pieces from top online stores like Amazon, Myntra, and Meesho. We provide links to help you find the best deals!
            </p>
            <div className="flex space-x-4">
              <Button variant="ghost" size="icon" className="text-pink-500 hover:text-pink-700 hover:bg-pink-100">
                <Facebook size={18} />
              </Button>
              <Button variant="ghost" size="icon" className="text-pink-500 hover:text-pink-700 hover:bg-pink-100">
                <Instagram size={18} />
              </Button>
              <Button variant="ghost" size="icon" className="text-pink-500 hover:text-pink-700 hover:bg-pink-100">
                <Linkedin size={18} />
              </Button>
              <Button variant="ghost" size="icon" className="text-pink-500 hover:text-pink-700 hover:bg-pink-100">
                <Twitter size={18} />
              </Button>
            </div>
          </div>

          {/* Shop */}
          <div>
            <h4 className="font-medium text-gray-900 mb-4">Shop</h4>
            <ul className="space-y-2">
              <li>
                <a href="/catalog?category=Dresses" className="text-gray-600 hover:text-pink-700 transition-colors">
                  Dresses
                </a>
              </li>
              <li>
                <a href="/catalog?category=Tops" className="text-gray-600 hover:text-pink-700 transition-colors">
                  Tops
                </a>
              </li>
              <li>
                <a href="/catalog?category=Bottoms" className="text-gray-600 hover:text-pink-700 transition-colors">
                  Bottoms
                </a>
              </li>
              <li>
                <a href="/catalog?category=Accessories" className="text-gray-600 hover:text-pink-700 transition-colors">
                  Accessories
                </a>
              </li>
              <li>
                <a href="/catalog" className="text-gray-600 hover:text-pink-700 transition-colors">
                  New Arrivals
                </a>
              </li>
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h4 className="font-medium text-gray-900 mb-4">Customer Service</h4>
            <ul className="space-y-2">
              <li>
                <a href="/contact" className="text-gray-600 hover:text-pink-700 transition-colors">
                  Contact Us
                </a>
              </li>
              <li>
                <a href="/about" className="text-gray-600 hover:text-pink-700 transition-colors">
                  Our Story
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-600 hover:text-pink-700 transition-colors">
                  Shipping & Returns
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-600 hover:text-pink-700 transition-colors">
                  FAQs
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-600 hover:text-pink-700 transition-colors">
                  Size Guide
                </a>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="font-medium text-gray-900 mb-4">Subscribe to our Newsletter</h4>
            <p className="text-gray-600 mb-4">
              Stay updated with our latest collections and exclusive offers.
            </p>
            <form onSubmit={handleSubscribe} className="flex">
              <Input
                type="email"
                placeholder="Your email address"
                className="rounded-r-none border-r-0 focus-visible:ring-pink-200"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <Button 
                type="submit" 
                variant="default"
                className="rounded-l-none bg-pink-600 hover:bg-pink-700"
                disabled={isSubmitting}
              >
                {isSubmitting ? "..." : "Join"}
              </Button>
            </form>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-pink-100 pt-6 mt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-500 text-sm mb-4 md:mb-0">
              &copy; {new Date().getFullYear()} Hruddha. All rights reserved. All purchases are made on respective e-commerce sites.
            </p>
            <div className="flex space-x-6">
              <a href="#" className="text-gray-500 hover:text-pink-700 text-sm">
                Privacy Policy
              </a>
              <a href="#" className="text-gray-500 hover:text-pink-700 text-sm">
                Terms of Service
              </a>
              <a href="#" className="text-gray-500 hover:text-pink-700 text-sm">
                Cookie Policy
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
